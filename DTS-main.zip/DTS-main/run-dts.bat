@echo off
setlocal EnableExtensions

REM ===========================================================================
REM  DTS - Run Backend and Frontend.
REM  Auto-installs dependencies if node_modules is missing so a fresh clone
REM  works on a double-click.
REM ===========================================================================

cd /d "%~dp0"

echo Starting Document Tracking System...
echo.

REM --- Verify Node.js / npm are available --------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js was not found on PATH.
  echo         Install Node.js LTS from https://nodejs.org/ and try again.
  echo.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo [ERROR] npm was not found on PATH.
  echo         Reinstall Node.js LTS so npm is registered, then try again.
  echo.
  pause
  exit /b 1
)

REM --- Install dependencies if node_modules is missing -------------------------
if not exist "%~dp0node_modules" (
  echo node_modules not found - installing dependencies first...
  echo --------------------------------------------------------------
  call npm install
  if errorlevel 1 (
    echo.
    echo [ERROR] npm install failed. Resolve the error above and rerun.
    echo.
    pause
    exit /b 1
  )
  echo.
  echo Dependencies installed.
  echo.
)

echo Backend : npm run start:backend
echo Frontend: npm run dev
echo.

start "DTS Backend"  cmd /k "pushd ""%~dp0"" && npm run start:backend"
start "DTS Frontend" cmd /k "pushd ""%~dp0"" && npm run dev"

echo Both services were launched in separate windows.
echo Close this window or keep it open.
endlocal
