import React, { useEffect, useState } from 'react';
import { CheckCircle, Download, FileText, Printer, Stamp, X, XCircle } from 'lucide-react';
import { apiJson, fetchDocumentBlob, fetchDocumentPreview, type DocumentPreview } from '../lib/api';

type ReviewMode = 'approval' | 'records';

export function DocumentApprovalModal({
  doc,
  mode = 'approval',
  onClose,
  onAction,
}: {
  doc: any;
  mode?: ReviewMode;
  onClose: () => void;
  onAction: (id: number, status: string, comment: string, placement?: { x: number; y: number }) => void;
}) {
  const [comment, setComment] = useState('');
  const [preview, setPreview] = useState<DocumentPreview | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewError, setPreviewError] = useState('');
  const [signatures, setSignatures] = useState<any[]>([]);
  const [placement, setPlacement] = useState({ x: 62, y: 70 });
  const [dragging, setDragging] = useState(false);

  const isRecordsMode = mode === 'records';
  const markerLabel = isRecordsMode ? 'RECEIVED' : 'SIGN HERE';

  useEffect(() => {
    if (!doc) return;
    let mounted = true;
    let objectUrl: string | null = null;
    setPreviewError('');
    setPreview(null);
    setPreviewUrl(null);
    fetchDocumentPreview(doc.doc_id)
      .then(async (documentPreview) => {
        if (!mounted) return;
        setPreview(documentPreview);

        if (documentPreview.type !== 'html') {
          const blob = await fetchDocumentBlob(doc.doc_id);
          if (!mounted) return;
          objectUrl = URL.createObjectURL(blob);
          setPreviewUrl(objectUrl);
        }
      })
      .catch((error: any) => {
        if (mounted) setPreviewError(error?.message || 'Unable to load secure preview.');
      });
    apiJson<{ signatures: any[] }>(`/api/documents/${doc.doc_id}/signatures`)
      .then((data) => {
        if (mounted) setSignatures(data.signatures || []);
      })
      .catch(() => {
        if (mounted) setSignatures([]);
      });
    return () => {
      mounted = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [doc]);

  if (!doc) return null;

  const moveMarker = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = Math.max(4, Math.min(82, ((event.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(8, Math.min(86, ((event.clientY - rect.top) / rect.height) * 100));
    setPlacement({ x, y });
  };

  const signDocument = async () => {
    try {
      await apiJson(`/api/documents/${doc.doc_id}/sign`, {
        method: 'POST',
        body: JSON.stringify({ placement }),
      });
      const updated = await apiJson<{ signatures: any[] }>(`/api/documents/${doc.doc_id}/signatures`);
      setSignatures(updated.signatures || []);
      return true;
    } catch (error: any) {
      setPreviewError(error?.message || 'Unable to sign document.');
      return false;
    }
  };

  const approve = async () => {
    if (!isRecordsMode) {
      const signed = await signDocument();
      if (!signed) return;
    }
    onAction(doc.doc_id, isRecordsMode ? 'For Review' : 'Approved', comment, placement);
  };

  const downloadDocument = async () => {
    try {
      const blob = await fetchDocumentBlob(doc.doc_id);
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = preview?.filename || doc.file_path || `${doc.tracking_number}.document`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    } catch (error: any) {
      setPreviewError(error?.message || 'Unable to download document.');
    }
  };

  const printDocument = () => {
    if (preview?.type === 'html') {
      const printWindow = window.open('', '_blank', 'noopener,noreferrer');
      if (!printWindow) return;
      printWindow.document.write(`
        <!doctype html>
        <html>
          <head>
            <title>${doc.title || 'Document Preview'}</title>
            <style>
              body { font-family: Arial, sans-serif; color: #1f2937; margin: 32px; line-height: 1.65; }
              table { border-collapse: collapse; width: 100%; }
              td, th { border: 1px solid #d1d5db; padding: 8px; vertical-align: top; }
              img { max-width: 100%; height: auto; }
            </style>
          </head>
          <body>${preview.html}</body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      return;
    }

    if (previewUrl) {
      const printWindow = window.open(previewUrl, '_blank', 'noopener,noreferrer');
      printWindow?.focus();
    }
  };

  const renderPreview = () => {
    if (previewError) {
      return <div className="p-4 text-xs font-bold text-red-600">{previewError}</div>;
    }

    if (!preview) {
      return <div className="p-4 text-xs font-bold text-slate-400">Loading secure preview...</div>;
    }

    if (preview.type === 'html') {
      return (
        <div className="h-full overflow-y-auto rounded-xl bg-white shadow-sm border border-slate-200">
          <article
            className="prose-preview min-h-full p-10 text-[15px] leading-7 text-slate-800"
            dangerouslySetInnerHTML={{ __html: preview.html || '<p>No readable text found in this document.</p>' }}
          />
        </div>
      );
    }

    if (preview.type === 'image' && previewUrl) {
      return (
        <div className="h-full overflow-auto rounded-xl bg-white shadow-sm border border-slate-200 flex items-start justify-center p-6">
          <img src={previewUrl} alt={doc.title || 'Document preview'} className="max-w-full h-auto object-contain" />
        </div>
      );
    }

    if (preview.type === 'pdf' && previewUrl) {
      return <iframe src={previewUrl} className="w-full h-full border-0 rounded-xl bg-white shadow-sm" />;
    }

    return (
      <div className="h-full rounded-xl bg-white shadow-sm border border-slate-200 flex flex-col items-center justify-center text-center p-10">
        <FileText className="w-12 h-12 text-slate-300 mb-4" />
        <p className="text-sm font-black text-slate-700 uppercase tracking-wide">Preview is not available for this file type</p>
        <button onClick={downloadDocument} className="mt-5 px-5 py-3 rounded-xl bg-[#2D5A27] text-white text-[10px] font-black uppercase tracking-widest">
          Download Document
        </button>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm">
      <div className="relative w-full max-w-7xl h-[86vh] grid grid-cols-[1.45fr_0.9fr] gap-6">
        <button
          onClick={onClose}
          className="absolute -right-3 -top-3 z-20 p-3 bg-white text-slate-400 hover:text-red-500 rounded-2xl shadow-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="bg-white rounded-[2rem] overflow-hidden flex flex-col shadow-2xl">
          <div className="px-7 py-5 bg-slate-50 border-b flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-50 text-[#2D5A27] flex items-center justify-center">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase text-slate-800">{doc.title}</h3>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  Official document preview - {doc.tracking_number}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button type="button" onClick={downloadDocument} className="p-3 rounded-xl bg-white text-slate-400 border border-slate-100 hover:text-[#2D5A27]"><Download className="w-4 h-4" /></button>
              <button type="button" onClick={printDocument} className="p-3 rounded-xl bg-white text-slate-400 border border-slate-100 hover:text-[#2D5A27]"><Printer className="w-4 h-4" /></button>
            </div>
          </div>

          <div
            className="relative flex-1 bg-slate-100 p-6 overflow-hidden"
            onPointerMove={moveMarker}
            onPointerUp={() => setDragging(false)}
            onPointerLeave={() => setDragging(false)}
          >
            {renderPreview()}

            <div
              onPointerDown={(event) => {
                event.preventDefault();
                setDragging(true);
              }}
              className={`absolute z-10 select-none cursor-grab active:cursor-grabbing rounded-xl border-2 px-5 py-3 shadow-xl bg-white/90 backdrop-blur-sm ${
                isRecordsMode ? 'border-blue-500 text-blue-700' : 'border-[#2D5A27] text-[#2D5A27]'
              }`}
              style={{ left: `${placement.x}%`, top: `${placement.y}%` }}
            >
              <div className="flex items-center gap-2">
                {isRecordsMode ? <Stamp className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                <span className="text-[11px] font-black uppercase tracking-widest">{markerLabel}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[2rem] p-7 shadow-2xl flex flex-col">
          <p className="text-[10px] font-black text-[#2D5A27] uppercase tracking-[0.25em] mb-5">
            {isRecordsMode ? 'Records Receiving Form' : 'Approval Form'}
          </p>

          <div className="rounded-2xl border border-slate-100 p-5 space-y-4 mb-5">
            <div className="flex justify-between gap-3 text-xs">
              <span className="font-black text-slate-400 uppercase tracking-widest">Tracking ID</span>
              <span className="font-black text-[#2D5A27]">{doc.tracking_number}</span>
            </div>
            <div className="flex justify-between gap-3 text-xs">
              <span className="font-black text-slate-400 uppercase tracking-widest">Destination</span>
              <span className="font-bold text-slate-700 text-right">{doc.destination || 'Department Office'}</span>
            </div>
            <div className="flex justify-between gap-3 text-xs">
              <span className="font-black text-slate-400 uppercase tracking-widest">Status</span>
              <span className="font-black text-amber-600">{doc.current_status}</span>
            </div>
          </div>

          <div className="mb-5 p-4 rounded-xl bg-slate-50 text-[10px] font-bold text-slate-600">
            Existing signatures: {signatures.length}
            {signatures.slice(-3).map((sig) => (
              <div key={sig.signature_id} className="mt-1">
                {sig.signer_name} - {new Date(sig.signed_at).toLocaleString()}
              </div>
            ))}
          </div>

          <textarea
            className="w-full flex-1 min-h-[150px] bg-slate-50 rounded-2xl p-4 mb-5 border-2 border-slate-100 focus:border-green-500 outline-none text-sm"
            placeholder={isRecordsMode ? 'Records remarks before stamping received...' : 'Approval comments or rejection reason...'}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => onAction(doc.doc_id, 'Rejected', comment, placement)}
              className="bg-red-500 text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2"
            >
              <XCircle className="w-5 h-5" />
              Reject
            </button>
            <button
              onClick={approve}
              className="bg-[#2D5A27] text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2"
            >
              {isRecordsMode ? <Stamp className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
              {isRecordsMode ? 'Stamp Received' : 'Approve'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
