import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FileText, ArrowRight } from 'lucide-react';

// In-export natin ito para magamit din ng ibang components
export interface Document {
  tracking_id: string;
  document_title: string;
  category: string;
  destination_office_name: string;
  status: string;
  created_at: string;
  // Idagdag natin ang optional fields para sa tracking
  description?: string;
  sender_name?: string;
}

interface DocumentTableProps {
  onSelectDocument: (doc: any) => void; // FIX #1 para sa App.tsx
  isAdmin: boolean;                     // FIX #2 para sa App.tsx
  filterStatus: string | null;          // FIX #3 para sa App.tsx
}

export const DocumentTable = ({ onSelectDocument, isAdmin, filterStatus }: DocumentTableProps) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/documents');
        setDocuments(response.data);
      } catch (error) {
        console.error("Error fetching documents:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDocuments();
  }, []);

  // Filter logic: Kung may piniling status sa dashboard, i-filter ang listahan
  const filteredDocuments = filterStatus 
    ? documents.filter(doc => doc.status === filterStatus)
    : documents;

  if (loading) {
    return (
      <div className="flex items-center justify-center p-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#2D5A27]"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
      <table className="w-full text-left border-collapse">
        <thead className="bg-gray-50/50">
          <tr>
            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Document Information</th>
            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Category</th>
            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Destination</th>
            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Current Status</th>
            <th className="px-8 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 text-right">Action</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {filteredDocuments.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-8 py-12 text-center text-gray-400 font-bold">
                No documents found {filterStatus ? `with status "${filterStatus}"` : ''}.
              </td>
            </tr>
          ) : (
            filteredDocuments.map((doc) => (
              <tr key={doc.tracking_id} className="hover:bg-gray-50/50 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#2D5A27]/5 flex items-center justify-center text-[#2D5A27] group-hover:bg-[#2D5A27] group-hover:text-white transition-all">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-black text-gray-900 leading-tight">{doc.document_title}</p>
                      <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-widest">{doc.tracking_id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <span className="text-xs font-bold text-gray-600 px-3 py-1 bg-gray-100 rounded-lg">{doc.category}</span>
                </td>
                <td className="px-8 py-5">
                  <p className="text-xs font-bold text-gray-500">{doc.destination_office_name || 'Department Office'}</p>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      doc.status === 'Completed' || doc.status === 'Signed' ? 'bg-green-500' : 'bg-orange-500'
                    }`} />
                    <span className="text-[10px] font-black uppercase tracking-wider text-gray-900">
                      {doc.status}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-5 text-right">
                  {/* Pinalitan natin ang button para gumana yung onSelectDocument function */}
                  <button 
                    onClick={() => onSelectDocument(doc)}
                    className="inline-flex items-center gap-2 text-[#2D5A27] font-black text-[10px] uppercase tracking-widest hover:gap-3 transition-all"
                  >
                    Track Record <ArrowRight className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};