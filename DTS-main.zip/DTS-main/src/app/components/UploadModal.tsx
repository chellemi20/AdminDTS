import React, { useState } from 'react';
import { X, FilePlus, Send, Shield, Info } from 'lucide-react';

interface NewDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function NewDocumentModal({ isOpen, onClose, onSuccess }: NewDocumentModalProps) {
  const [formData, setFormData] = useState({
    document_title: '',
    category: 'Administrative',
    priority: 'Normal',
    destination_office_id: '',
    description: ''
  });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        onSuccess(); // Refresh ang list sa dashboard
        onClose();   // Isara ang modal
      }
    } catch (error) {
      console.error("Error saving document:", error);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/20 animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="bg-[#2D5A27] p-8 text-white relative">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-2xl border border-white/10">
              <FilePlus className="w-6 h-6 text-[#E9C46A]" />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-widest">Create Document</h2>
              <p className="text-[10px] font-bold text-white/60 uppercase tracking-[0.2em] mt-1">Registry Entry • Official Track</p>
            </div>
          </div>
          <button onClick={onClose} className="absolute top-8 right-8 p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            {/* Document Title */}
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Document Subject</label>
              <input 
                required
                className="w-full mt-2 p-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-[#2D5A27]/20 focus:border-[#2D5A27] transition-all outline-none"
                placeholder="e.g. Regional Budget Proposal 2026"
                onChange={(e) => setFormData({...formData, document_title: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Category */}
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Category</label>
                <select 
                  className="w-full mt-2 p-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold appearance-none outline-none"
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                >
                  <option>Administrative</option>
                  <option>Financial</option>
                  <option>Legal</option>
                  <option>Technical</option>
                </select>
              </div>

              {/* Priority */}
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Priority Level</label>
                <select 
                  className="w-full mt-2 p-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold appearance-none outline-none"
                  onChange={(e) => setFormData({...formData, priority: e.target.value})}
                >
                  <option>Normal</option>
                  <option>High</option>
                  <option>Urgent</option>
                </select>
              </div>
            </div>

            {/* Destination Office */}
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Destination Office ID</label>
              <div className="relative mt-2">
                <Shield className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                <input 
                  required
                  className="w-full p-4 pl-12 bg-slate-50 border border-slate-100 rounded-2xl text-sm font-bold outline-none"
                  placeholder="Enter Office Code (e.g. REG-04)"
                  onChange={(e) => setFormData({...formData, destination_office_id: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 flex items-center justify-between border-t border-slate-50">
            <div className="flex items-center gap-2 text-slate-300">
              <Info className="w-3 h-3" />
              <span className="text-[9px] font-bold uppercase tracking-tighter">Auto-generates Tracking ID</span>
            </div>
            <button 
              type="submit"
              className="px-8 py-4 bg-[#2D5A27] text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] flex items-center gap-3 hover:bg-[#1a3516] hover:shadow-lg hover:shadow-green-900/20 transition-all active:scale-95"
            >
              <Send className="w-4 h-4 text-[#E9C46A]" />
              Initialize Route
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}