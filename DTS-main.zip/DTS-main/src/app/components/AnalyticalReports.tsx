import React, { useEffect, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { 
  Download, TrendingUp, Clock, AlertCircle, ChevronRight, ArrowUpRight, 
  FileText, Calendar, CheckCircle2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { apiJson } from '../lib/api';

type WeeklyStat = { week: string; approved: number };
type RecentCompleted = {
  document_title?: string;
  tracking_id?: string;
  due_date?: string | null;
  status?: string;
};

const DEFAULT_ANALYTICS = {
  totalProcessed: 0,
  avgApprovalTime: "0h",
  overdueTasks: 0,
  weeklyStats: [] as WeeklyStat[],
  recentCompleted: [] as RecentCompleted[],
};

// Inayos ang Props para tanggapin ang 'documents' mula sa App.tsx
export const AnalyticalReports = ({ documents = [] }: any) => {
  const [analyticsData, setAnalyticsData] = useState(DEFAULT_ANALYTICS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const data = await apiJson<any>('/analytics-summary');
        // Merge defensively: only adopt fields the API actually returned, so a
        // partial response (e.g. just total/pending counts) cannot wipe out
        // the array defaults and crash the table/chart below.
        setAnalyticsData((prev) => ({
          ...prev,
          ...(data ?? {}),
          totalProcessed:
            data?.totalProcessed ?? data?.total_documents ?? documents.length,
          avgApprovalTime: data?.avgApprovalTime ?? prev.avgApprovalTime,
          overdueTasks: data?.overdueTasks ?? prev.overdueTasks,
          weeklyStats: Array.isArray(data?.weeklyStats)
            ? data.weeklyStats
            : prev.weeklyStats,
          recentCompleted: Array.isArray(data?.recentCompleted)
            ? data.recentCompleted
            : prev.recentCompleted,
        }));
      } catch (err) {
        console.error("Failed to fetch analytics:", err);
        setAnalyticsData((prev) => ({
          ...prev,
          totalProcessed: documents.length,
        }));
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [documents]);

  const weeklyStats = Array.isArray(analyticsData.weeklyStats)
    ? analyticsData.weeklyStats
    : [];
  const recentCompleted = Array.isArray(analyticsData.recentCompleted)
    ? analyticsData.recentCompleted
    : [];

  if (loading) return (
    <div className="h-96 flex items-center justify-center">
       <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] animate-pulse">
         Synchronizing Database Analytics...
       </p>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Performance & Analytics</h2>
          <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-[10px] mt-2 flex items-center gap-2">
            <TrendingUp className="w-3 h-3 text-[#2D5A27]" />
            Live Productivity Oversight • {new Date().toLocaleString('default', { month: 'long' })} {new Date().getFullYear()}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-3 bg-white text-slate-600 border border-slate-200 px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm active:scale-95">
            <Download className="w-4 h-4" /> Excel
          </button>
          <button className="flex items-center gap-3 bg-[#2D5A27] text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-[#1a3818] transition-all shadow-xl shadow-green-900/20 active:scale-95 border-b-4 border-[#1a3516]">
            <Download className="w-4 h-4" /> Download Monthly Report (PDF)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-50 relative overflow-hidden group">
          <div className="p-4 bg-green-50 rounded-2xl text-[#2D5A27] w-fit mb-6 transition-transform group-hover:scale-110"><FileText className="w-6 h-6" /></div>
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Documents Processed</p>
          <h3 className="text-4xl font-black text-slate-900 leading-none">{analyticsData.totalProcessed.toLocaleString()}</h3>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-50 relative overflow-hidden group">
          <div className="p-4 bg-amber-50 rounded-2xl text-[#E9C46A] w-fit mb-6 transition-transform group-hover:scale-110"><Clock className="w-6 h-6" /></div>
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-1">Average Approval Time</p>
          <h3 className="text-4xl font-black text-slate-900 leading-none">{analyticsData.avgApprovalTime}</h3>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-50 relative overflow-hidden group">
          <div className="p-4 bg-orange-50 rounded-2xl text-[#E76F51] w-fit mb-6 transition-transform group-hover:scale-110"><AlertCircle className="w-6 h-6" /></div>
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-1">Overdue / Delayed Tasks</p>
          <h3 className="text-4xl font-black text-[#E76F51] leading-none">{analyticsData.overdueTasks}</h3>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} className="bg-white p-10 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-50 flex flex-col">
          <div className="flex items-center justify-between mb-10 text-xl font-black text-slate-800 tracking-tight">
            <h3>Monthly Productivity</h3>
          </div>
          <div className="h-[350px] w-full mt-auto relative">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyStats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#94a3b8' }} dy={15} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#94a3b8' }} />
                <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)', padding: '20px' }} />
                <Bar dataKey="approved" fill="#2D5A27" radius={[12, 12, 0, 0]} barSize={64} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} className="bg-white p-10 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-50 flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-slate-800 tracking-tight">Deadline Tracker</h3>
            <div className="p-3 bg-slate-50 rounded-2xl text-slate-400"><Calendar className="w-5 h-5" /></div>
          </div>
          <div className="flex-1 overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <th className="pb-6">Document</th>
                  <th className="pb-6">Original Due Date</th>
                  <th className="pb-6 text-right">Variance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {recentCompleted.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-10 text-center text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
                      No completed documents yet
                    </td>
                  </tr>
                )}
                {recentCompleted.map((doc: RecentCompleted, i: number) => (
                  <tr key={i} className="group hover:bg-slate-50/50 transition-colors">
                    <td className="py-5">
                      <div className="flex items-center gap-3">
                        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm", doc.status === 'Delayed' ? "bg-orange-50 text-[#E76F51]" : "bg-green-50 text-[#2D5A27]")}>
                          {doc.status === 'Delayed' ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
                        </div>
                        <div>
                          <p className="text-xs font-black text-slate-800 leading-none">{doc.document_title || "Untitled"}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase mt-1 tracking-tight">{doc.tracking_id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-5 text-[11px] font-bold text-slate-600">
                      {doc.due_date ? new Date(doc.due_date).toLocaleDateString() : "No Date"}
                    </td>
                    <td className="py-5 text-right">
                      <span className={cn("px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest", doc.status === 'Delayed' ? "bg-orange-100 text-[#E76F51]" : "bg-green-100 text-[#2D5A27]")}>
                        {doc.status || "Pending"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, scale: 0.98 }} whileInView={{ opacity: 1, scale: 1 }} className="bg-[#2D5A27] rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl shadow-green-900/40">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-10">
          <div className="space-y-4">
            <h3 className="text-3xl font-black tracking-tight leading-none uppercase">Departmental Efficiency</h3>
            <p className="text-white/60 text-sm font-medium max-w-lg">
              Live efficiency tracking based on current document turnaround times across all DA bureaus.
            </p>
          </div>
          <button className="px-10 py-6 bg-[#E9C46A] text-[#2D5A27] rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl hover:bg-[#d4b35b] transition-all border-b-4 border-[#c9a64b]">
            Download Full Insight Audit
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// Inayos ang cn function para sa TypeScript
function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}