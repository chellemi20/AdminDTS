import React, { useEffect, useMemo, useState } from 'react';
import { Activity, RefreshCw, ShieldCheck } from 'lucide-react';
import { apiJson } from '../lib/api';

type AuditLog = {
  audit_id: number;
  actor_user_id: number | null;
  actor_name: string | null;
  actor_role: string | null;
  action: string;
  target_type: string;
  target_id: string;
  ip_address: string | null;
  metadata: any;
  created_at: string;
};

const actionLabels: Record<string, string> = {
  'user.login': 'User Login',
  'user.register': 'Account Registration',
  'user.status.update': 'Account Status Update',
  'user.profile_image.upload': 'Profile Image Upload',
  'document.upload': 'Document Upload',
  'document.view': 'Document Opened',
  'document.status.update': 'Document Status Update',
  'document.signature.apply': 'Digital Signature Applied',
  'document.access_request.create': 'Access Request Created',
  'document.access_request.approve': 'Access Request Approved',
  'document.access_request.deny': 'Access Request Denied',
  'system.backup.run': 'System Backup Run',
};

export function ActivityLogs() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  const loadLogs = async () => {
    setIsLoading(true);
    setError('');
    try {
      const data = await apiJson<AuditLog[]>('/api/admin/audit-logs?limit=200');
      setLogs(data);
    } catch (err) {
      setError((err as Error)?.message || 'Unable to load activity logs.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  const summary = useMemo(() => {
    const uniqueUsers = new Set(logs.map((log) => log.actor_user_id).filter(Boolean));
    const today = new Date().toDateString();
    return {
      total: logs.length,
      users: uniqueUsers.size,
      today: logs.filter((log) => new Date(log.created_at).toDateString() === today).length,
    };
  }, [logs]);

  return (
    <div className="max-w-[1500px] mx-auto w-full space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-xl bg-[#2D5A27] text-white flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Activity Logs</h1>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Super Admin monitoring console</p>
            </div>
          </div>
        </div>
        <button
          onClick={loadLogs}
          disabled={isLoading}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 bg-white border border-slate-200 rounded-xl text-xs font-black uppercase tracking-widest text-[#2D5A27] hover:bg-slate-50 disabled:opacity-60"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          ['Total Events', summary.total],
          ['Active Users', summary.users],
          ['Events Today', summary.today],
        ].map(([label, value]) => (
          <div key={label} className="bg-white border border-slate-100 rounded-[8px] p-5 shadow-sm">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{label}</p>
            <p className="text-3xl font-black text-[#2D5A27] mt-2">{value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-100 rounded-[8px] shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center gap-3">
          <Activity className="w-5 h-5 text-[#2D5A27]" />
          <h2 className="text-sm font-black uppercase tracking-widest text-slate-700">Recent User Activity</h2>
        </div>

        {error && <div className="m-6 p-4 rounded-lg bg-red-50 text-red-600 text-xs font-bold">{error}</div>}

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Time</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">User</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Action</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Target</th>
                <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-16 text-center text-xs font-black uppercase tracking-widest text-slate-400">Loading activity logs...</td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-16 text-center text-xs font-black uppercase tracking-widest text-slate-400">No activity logs yet</td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.audit_id} className="hover:bg-slate-50/70">
                    <td className="px-6 py-4 text-xs font-bold text-slate-500 whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs font-black text-slate-800 uppercase">{log.actor_name || 'System'}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">{log.actor_role || 'Automated'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex px-3 py-1 rounded-full bg-[#2D5A27]/10 text-[#2D5A27] text-[10px] font-black uppercase tracking-widest">
                        {actionLabels[log.action] || log.action}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs font-bold text-slate-500">
                      {log.target_type} #{log.target_id}
                    </td>
                    <td className="px-6 py-4 text-xs font-mono text-slate-400">{log.ip_address || 'n/a'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
