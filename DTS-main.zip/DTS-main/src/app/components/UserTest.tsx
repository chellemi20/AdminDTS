import { useEffect, useState } from 'react';

export function UserTest() {
  const [dbStatus, setDbStatus] = useState<'loading' | 'connected' | 'error'>('loading');
  const [userCount, setUserCount] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('http://localhost:5000/users')
      .then((res) => {
        if (!res.ok) throw new Error("Server error: " + res.status);
        return res.json();
      })
      .then((data) => {
        setDbStatus('connected');
        setUserCount(data.length);
      })
      .catch((err) => {
        setDbStatus('error');
        setError(err.message);
      });
  }, []);

  // Error State - Malinis na pulang indicator
  if (dbStatus === 'error') return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-red-50 border border-red-100 rounded-full">
      <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
      <span className="text-[10px] font-black text-red-600 uppercase tracking-wider">Offline</span>
    </div>
  );

  // Loading State
  if (dbStatus === 'loading') return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-full animate-pulse">
      <div className="w-1.5 h-1.5 rounded-full bg-slate-300" />
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Connecting...</span>
    </div>
  );

  // Success State - Emerald green indicator na may pulse effect
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-100 rounded-full shadow-sm shadow-emerald-900/5">
        <div className="relative">
          <div className="w-2 h-2 rounded-full bg-emerald-500" />
          <div className="absolute inset-0 w-2 h-2 rounded-full bg-emerald-500 animate-ping opacity-75" />
        </div>
        <span className="text-[10px] font-black text-emerald-700 uppercase tracking-[0.15em]">
          Database Live
        </span>
      </div>
      
      {/* Optional: Maliit na counter para malaman kung may users na sa DB */}
      <div className="hidden sm:block text-[10px] font-bold text-slate-400 uppercase tracking-widest">
        {userCount} Registered {userCount === 1 ? 'User' : 'Users'}
      </div>
    </div>
  );
}