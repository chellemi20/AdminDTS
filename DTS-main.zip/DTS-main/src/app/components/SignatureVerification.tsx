import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Fingerprint, ShieldCheck, X, Lock, UserCheck, Calendar } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SignatureVerificationProps {
  onConfirm: () => void;
  onCancel: () => void;
  userName: string;
}

export function SignatureVerification({ onConfirm, onCancel, userName }: SignatureVerificationProps) {
  const [pin, setPin] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const today = new Date().toISOString().split('T')[0];

  const handleConfirm = () => {
    if (pin.length < 4) return;
    setIsVerifying(true);
    setTimeout(() => {
      onConfirm();
    }, 1500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-sm"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl border border-white/20 overflow-hidden relative"
      >
        {/* Header */}
        <div className="p-8 text-center space-y-2 border-b border-slate-50">
          <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-green-100 shadow-inner">
            <ShieldCheck className="w-8 h-8 text-[#2D5A27]" />
          </div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">Digital Signature</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Secure Document Authentication</p>
        </div>

        <div className="p-8 space-y-8">
          {/* Signature Preview */}
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Signature Preview</label>
            <div className="bg-[#F8F9FA] rounded-2xl p-8 border-2 border-dashed border-slate-200 relative group overflow-hidden">
              <div className="absolute inset-0 bg-green-900/0 group-hover:bg-green-900/5 transition-colors duration-300" />
              <div className="relative flex flex-col items-center gap-4">
                 {/* Handwritten style font */}
                <p className="text-3xl font-serif italic text-slate-800 font-medium select-none transform -rotate-2">
                  {userName}
                </p>
                <div className="h-px w-32 bg-slate-200" />
                <div className="flex flex-col items-center gap-1">
                  <p className="text-[9px] font-black text-[#2D5A27] uppercase tracking-tighter">Digitally Signed By: {userName}</p>
                  <div className="flex items-center gap-2 text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                    <Calendar className="w-2.5 h-2.5" />
                    {today} • SECURE-DA-HASH-V4
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* PIN Input */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Enter Security PIN to Confirm Signature</label>
              <div className="relative group">
                <div className="absolute left-5 top-1/2 -translate-y-1/2">
                  <Lock className="w-4 h-4 text-slate-300 group-focus-within:text-[#2D5A27] transition-colors" />
                </div>
                <input 
                  type="password"
                  maxLength={6}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="••••••"
                  className="w-full bg-slate-50 border-2 border-slate-100 focus:bg-white focus:border-[#2D5A27]/20 rounded-2xl py-4 pl-14 pr-6 text-xl tracking-[0.5em] font-black outline-none transition-all placeholder:text-slate-200 placeholder:tracking-normal"
                />
              </div>
            </div>

            {/* Biometric Prompt */}
            <button className="w-full flex items-center justify-center gap-3 py-3 rounded-xl border border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:bg-slate-50 transition-all group">
              <Fingerprint className="w-4 h-4 group-hover:text-[#2D5A27] transition-colors" />
              Use Biometric (FaceID / Fingerprint)
            </button>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4 pt-2">
            <button 
              disabled={pin.length < 4 || isVerifying}
              onClick={handleConfirm}
              className={cn(
                "w-full py-5 rounded-2xl bg-[#2D5A27] text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-green-900/20 transition-all active:scale-95 flex items-center justify-center gap-3",
                (pin.length < 4 || isVerifying) && "opacity-50 cursor-not-allowed shadow-none"
              )}
            >
              {isVerifying ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <UserCheck className="w-4 h-4" />
              )}
              {isVerifying ? 'Verifying Identity...' : 'CONFIRM & SIGN'}
            </button>
            <button 
              onClick={onCancel}
              className="w-full py-2 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-red-500 transition-all text-center"
            >
              Cancel & Back to Review
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
