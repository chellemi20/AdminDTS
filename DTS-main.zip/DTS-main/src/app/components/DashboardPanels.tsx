import React from "react";
import { Eye } from "lucide-react";

export function DashboardPanels({ documents = [], onViewDoc }: any) {
  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
      <div className="p-10 border-b border-slate-50 flex items-center justify-between">
        <div>
          <h3 className="text-xl font-black text-slate-800 tracking-tight">Recent Routing Activities</h3>
          <p className="text-[10px] font-bold text-green-600 uppercase tracking-widest mt-1">● Live Document Stream</p>
        </div>
      </div>

      <table className="w-full text-left">
        <thead>
          <tr className="bg-slate-50/30">
            <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Tracking ID</th>
            <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Subject</th>
            <th className="px-6 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
            <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Action</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {documents && documents.length > 0 ? (
            documents.map((doc: any) => (
             
              <tr key={doc.id || doc.tracking_id} className="group hover:bg-slate-50/50 transition-colors">
                <td className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase">
                  {}
                  {doc.tracking_id || doc.tracking_number || "N/A"}
                </td>
                <td className="px-6 py-7">
                  <p className="text-sm font-black text-slate-800 leading-none">
                    {}
                    {doc.document_title || doc.document_name || "Untitled"}
                  </p>
                </td>
                <td className="px-6 py-7">
                  <span className={`px-3 py-1 text-[9px] font-black rounded-full uppercase border ${
                    doc.status === 'Pending' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-green-50 text-[#2D5A27] border-green-100'
                  }`}>
                    {doc.status || "Unknown"}
                  </span>
                </td>
                <td className="px-10 py-7 text-right">
                  <button 
                    onClick={() => onViewDoc(doc)} 
                    className="p-2.5 hover:bg-green-50 rounded-xl transition-all"
                  >
                    <Eye className="w-4 h-4 text-slate-300 hover:text-[#2D5A27]" />
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={4} className="py-20 text-center text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">
                No records found in database
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}