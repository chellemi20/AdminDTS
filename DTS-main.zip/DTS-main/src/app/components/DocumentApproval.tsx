import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock, 
  MessageSquare, 
  Download,
  Printer,
  Loader2
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { toast } from "sonner";
import { BRAND_LOGO_URL } from '../lib/brand';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DocumentApprovalProps {
  documentId: string;
  onBack: () => void;
  onApprove: () => void;
  viewOnly?: boolean;
}

export function DocumentApproval({ documentId, onBack, onApprove, viewOnly = false }: DocumentApprovalProps) {
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleAction = async (type: 'approve' | 'reject') => {
    setIsSubmitting(true);
    
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 1200));

    if (type === 'approve') {
      toast.success(`Document ${documentId} has been successfully approved.`);
      onApprove();
    } else {
      toast.error(`Document ${documentId} has been returned to the originator.`);
      onBack();
    }
    setIsSubmitting(false);
  };

  const history = [
    { user: 'J. Dela Cruz', role: 'Admin Staff', action: 'Uploaded Document', date: 'Feb 15, 2026 09:00 AM', status: 'completed' },
    { user: 'Dir. M. Santos', role: 'Crops Dept Head', action: 'Reviewed & Verified', date: 'Feb 15, 2026 02:30 PM', status: 'completed' },
    { user: 'Director Office', role: 'Final Approval', action: 'FOR YOUR DECISION', date: 'Pending', status: 'current' },
  ];

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 md:p-12 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 40 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className={cn(
          "flex w-full max-w-[1440px] h-full max-h-[900px] gap-8 overflow-hidden bg-white/40 rounded-[3.5rem] p-4 border border-white/40 shadow-2xl relative",
          viewOnly && "max-w-[1000px]"
        )}
      >
        {/* Close Button */}
        <button 
          onClick={onBack}
          className="absolute top-8 right-8 p-3 bg-white text-slate-400 hover:text-red-500 rounded-2xl shadow-lg border border-slate-100 transition-all z-[1010] active:scale-90"
        >
          <XCircle className="w-6 h-6" />
        </button>

        {/* LEFT PANEL: PDF Preview */}
        <div className="flex-1 bg-white rounded-[2.5rem] border border-slate-200/50 overflow-hidden flex flex-col shadow-xl">
          <div className="bg-slate-50/80 px-10 py-6 border-b border-slate-100 flex justify-between items-center">
            <div className="flex items-center gap-5">
              <div className="p-3 bg-green-100 rounded-2xl text-[#1B5E20]">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Seed_Distribution_Proposal_2026.pdf</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  Tracking ID: <span className="text-[#1B5E20]">{documentId}</span>
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 mr-12">
              <button className="p-3 text-slate-400 hover:bg-slate-100 rounded-xl transition-all"><Download className="w-5 h-5" /></button>
              <button className="p-3 text-slate-400 hover:bg-slate-100 rounded-xl transition-all"><Printer className="w-5 h-5" /></button>
            </div>
          </div>
          
          {/* Document Content Preview */}
          <div className="flex-1 overflow-y-auto p-12 bg-slate-100/50 custom-scrollbar">
            <div className="bg-white w-full max-w-[800px] mx-auto shadow-sm rounded-sm p-16 border border-slate-200 min-h-[1000px]">
              {/* DA Letterhead */}
              <div className="flex flex-col items-center mb-16 text-center">
                <img src={BRAND_LOGO_URL} alt="DA Logo" className="w-20 h-20 mb-4" />
                <p className="text-[10px] font-serif uppercase tracking-[0.2em] text-slate-500">Republic of the Philippines</p>
                <h1 className="text-xl font-serif font-bold text-[#1B5E20] uppercase tracking-wide">Department of Agriculture</h1>
                <p className="text-[10px] font-serif text-slate-400 uppercase">Regional Field Office No. IV-A</p>
                <div className="w-32 h-0.5 bg-[#1B5E20]/30 mt-6" />
              </div>

              {/* Document Text */}
              <div className="space-y-8 font-serif text-slate-800">
                <div className="flex justify-between text-[11px] font-bold uppercase border-b pb-2 text-slate-400">
                  <span>Ref: {documentId}</span>
                  <span>Date: February 16, 2026</span>
                </div>
                
                <h2 className="text-xl font-bold text-center underline decoration-[#1B5E20] underline-offset-8">MEMORANDUM</h2>
                
                <div className="space-y-4 text-sm leading-relaxed">
                  <p><span className="font-bold">FOR:</span> Regional Executive Director</p>
                  <p><span className="font-bold">FROM:</span> Crops Department Head</p>
                  <p><span className="font-bold">SUBJECT:</span> STRATEGIC SEED DISTRIBUTION PROGRAM (FY 2026)</p>
                </div>

                <div className="h-px bg-slate-100 my-8" />

                <div className="text-sm space-y-6 text-justify">
                  <p>This is to formally request approval for the distribution of <span className="font-bold">5,000 bags of hybrid rice seeds</span> to cooperatives in Batangas and Laguna. This initiative aims to address seed security concerns for the upcoming cropping season.</p>
                  <p>Total budgetary requirement for this phase is <span className="font-bold">PHP 13,700,000.00</span>, inclusive of logistics and provincial storage fees as detailed in the attached technical specification sheet.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT PANEL: Decision Sidebar */}
        {!viewOnly && (
          <div className="w-[420px] bg-white rounded-[2.5rem] border border-slate-200 shadow-xl flex flex-col">
            <div className="p-8 space-y-10 overflow-y-auto flex-1 custom-scrollbar">
              
              {/* Routing History Section */}
              <div className="space-y-6">
                <h4 className="text-[10px] font-black text-[#1B5E20] uppercase tracking-[0.2em] flex items-center gap-2">
                   Routing History
                </h4>
                <div className="space-y-6 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-px before:bg-slate-100 pl-1">
                  {history.map((step, i) => (
                    <div key={i} className="flex gap-4 relative">
                      <div className={cn(
                        "w-5 h-5 rounded-full z-10 border-2 border-white shadow-md",
                        step.status === 'completed' ? "bg-[#1B5E20]" : "bg-amber-400 animate-pulse"
                      )} />
                      <div className="flex flex-col -mt-1">
                        <p className="text-xs font-bold text-slate-800">{step.user}</p>
                        <p className="text-[10px] text-slate-400 uppercase tracking-tighter">{step.role}</p>
                        <p className="text-[9px] font-bold text-[#1B5E20] mt-1">{step.action}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Remarks Section */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-[#1B5E20] uppercase tracking-[0.2em]">Remarks / Feedback</h4>
                <textarea 
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Write your comments here..."
                  className="w-full h-40 bg-slate-50 border-2 border-slate-100 rounded-2xl p-5 text-sm outline-none focus:border-green-200 transition-all resize-none shadow-inner"
                />
              </div>
            </div>

            {/* Final Action Buttons */}
            <div className="p-8 bg-slate-50 border-t border-slate-100 grid grid-cols-2 gap-4">
              <button 
                disabled={isSubmitting}
                onClick={() => handleAction('reject')}
                className="flex flex-col items-center py-5 bg-white border-2 border-slate-200 rounded-3xl text-slate-600 hover:bg-red-50 hover:border-red-200 transition-all group"
              >
                <XCircle className="w-5 h-5 mb-1 group-hover:text-red-500" />
                <span className="text-[10px] font-black uppercase">Return</span>
              </button>
              <button 
                disabled={isSubmitting}
                onClick={() => handleAction('approve')}
                className="flex flex-col items-center py-5 bg-[#1B5E20] rounded-3xl text-white hover:bg-[#0E3A14] shadow-lg shadow-green-900/20 transition-all"
              >
                {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin mb-1" /> : <CheckCircle className="w-5 h-5 mb-1" />}
                <span className="text-[10px] font-black uppercase">Approve</span>
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
