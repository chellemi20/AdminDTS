import React from 'react';
import { 
  MessageSquare, 
  UserCheck, 
  FileSignature, 
  ArrowRight 
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** * Utility for Tailwind classes merging 
 */
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Data Interfaces
 */
interface ChatActivity {
  id: number;
  user: string;
  role: string;
  message: string;
  time: string;
}

interface ApprovalItem {
  id: string;
  title: string;
  department: string;
  priority: 'Urgent' | 'High' | 'Low';
}

/**
 * Mock Data
 */
const recentChats: ChatActivity[] = [
  { id: 1, user: 'Maria Santos', role: 'Admin Staff', message: 'Budget proposal for Region IV has been uploaded.', time: '2m ago' },
  { id: 2, user: 'Ricardo Ramos', role: 'Admin Head', message: 'Director requested an urgent review of the irrigation report.', time: '15m ago' },
  { id: 3, user: 'System Bot', role: 'Automated', message: 'Daily document digest is now available for download.', time: '1h ago' },
];

const approvalQueue: ApprovalItem[] = [
  { id: 'DA-2026-089', title: 'Seed Subsidy Grant', department: 'Livestock', priority: 'Urgent' },
  { id: 'DA-2026-092', title: 'Monthly Fuel Voucher', department: 'Finance', priority: 'High' },
  { id: 'DA-2026-104', title: 'Staff Training Expense', department: 'HR', priority: 'Low' },
];

export function DashboardFooter() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
      
      {/* 1. INTERNAL COORDINATION (CHATS) */}
      <div className="bg-white rounded-[20px] border border-gray-100 shadow-sm flex flex-col h-[450px] overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-50 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#2D5A27]/10 rounded-lg">
              <MessageSquare className="w-5 h-5 text-[#2D5A27]" />
            </div>
            <h3 className="font-black text-sm uppercase tracking-wider text-gray-900">Internal Coordination</h3>
          </div>
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-gray-50 px-3 py-1 rounded-full border border-gray-100">
            Live Updates
          </span>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar bg-[#FDFDFD]">
          {recentChats.map((chat) => (
            <div 
              key={chat.id} 
              className="group p-4 bg-white rounded-2xl border border-gray-100 hover:border-[#2D5A27]/20 hover:shadow-md transition-all cursor-default"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-slate-800">{chat.user}</span>
                  <span className="text-[9px] font-black text-[#2D5A27] uppercase tracking-tighter bg-[#2D5A27]/5 px-2 py-0.5 rounded-md">
                    {chat.role}
                  </span>
                </div>
                <span className="text-[10px] font-bold text-gray-300">{chat.time}</span>
              </div>
              <p className="text-sm text-slate-500 line-clamp-2 leading-relaxed">{chat.message}</p>
            </div>
          ))}
        </div>
        
        <div className="p-4 bg-white border-t border-gray-50">
          <button className="w-full py-3 text-[10px] font-black text-[#2D5A27] uppercase tracking-[0.2em] flex items-center justify-center gap-2 hover:bg-gray-50 rounded-xl transition-all border border-transparent hover:border-gray-100">
            Open Messaging Center <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 2. APPROVAL QUEUE (SIGNING) */}
      <div className="bg-white rounded-[20px] border border-gray-100 shadow-sm flex flex-col h-[450px] overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-50 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#E9C46A]/10 rounded-lg">
              <FileSignature className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-black text-sm uppercase tracking-wider text-gray-900">Approval Queue</h3>
          </div>
          <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse"></div>
             <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{approvalQueue.length} Pending</span>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-3 custom-scrollbar bg-[#FDFDFD]">
          {approvalQueue.map((item) => (
            <div 
              key={item.id} 
              className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-2xl hover:border-[#E9C46A]/40 transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center group-hover:bg-[#E9C46A]/20 transition-colors">
                  <UserCheck className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-sm font-black text-slate-800 leading-none mb-1 group-hover:text-[#2D5A27] transition-colors">{item.title}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold text-gray-300">{item.id}</span>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-tighter">• {item.department}</span>
                  </div>
                </div>
              </div>
              <button className="px-4 py-2 bg-[#2D5A27] text-white text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-[#1a3516] transition-all shadow-sm hover:shadow-md flex items-center gap-2">
                Sign <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
        
        <div className="p-5 bg-gray-50 border-t border-gray-100">
          <div className="flex items-center justify-center gap-2 text-[9px] font-black text-gray-400 uppercase tracking-[0.2em]">
            <ShieldCheck className="w-3 h-3 text-[#2D5A27]" />
            Encrypted Digital Signature Active
          </div>
        </div>
      </div>

      {/* Internal Custom Scrollbar Styling */}
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #E2E8F0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #CBD5E1;
        }
      `}} />
    </div>
  );
}

/**
 * Icons
 */
function ShieldCheck({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/>
    </svg>
  );
}