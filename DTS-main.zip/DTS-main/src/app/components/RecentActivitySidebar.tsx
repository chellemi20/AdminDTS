import React from 'react';
import { motion } from 'motion/react';
import { Clock, CheckCircle2, AlertCircle, ArrowRight, User } from 'lucide-react';

interface Activity {
  id: string;
  user: string;
  action: string;
  time: string;
  status: 'Completed' | 'In Transit' | 'Delayed' | 'Pending';
  avatar?: string;
}

const activities: Activity[] = [
  { id: '1', user: 'Regional Office III', action: 'received Seed Distribution Proposal (DA-2026-001)', time: '2 mins ago', status: 'Completed' },
  { id: '2', user: 'Finance Division', action: 'reviewed Budget Realignment for Fisheries', time: '15 mins ago', status: 'In Transit' },
  { id: '3', user: 'Director Office', action: 'signed Special Order for Personnel Training', time: '1 hour ago', status: 'Completed' },
  { id: '4', user: 'Crops Department', action: 'forwarded Irrigation Report to Regional Hub', time: '3 hours ago', status: 'Delayed' },
  { id: '5', user: 'Livestock Bureau', action: 'uploaded Quarterly Poultry Census', time: '5 hours ago', status: 'In Transit' },
  { id: '6', user: 'System Admin', action: 'archived Completed Resolution 2025-08', time: 'Yesterday', status: 'Completed' },
  { id: '7', user: 'Regional Office VII', action: 'dispatched Fertilizer Subsidy Vouchers', time: 'Yesterday', status: 'Pending' },
];

export function RecentActivitySidebar() {
  return (
    <div className="w-[380px] h-screen bg-white border-l border-slate-100 flex flex-col sticky top-0 shrink-0 shadow-[-20px_0_40px_rgba(0,0,0,0.02)] z-40 overflow-hidden">
      <div className="p-8 border-b border-slate-50 shrink-0 bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-black text-slate-900 tracking-tight">Recent Route Activities</h2>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#2D5A27]/5 rounded-full">
            <div className="w-1.5 h-1.5 rounded-full bg-[#2D5A27] animate-pulse"></div>
            <span className="text-[10px] font-black text-[#2D5A27] uppercase tracking-widest">Live</span>
          </div>
        </div>
        <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none">Real-time document tracking log</div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-thin scrollbar-thumb-slate-200">
        {activities.map((activity, i) => (
          <motion.div 
            key={activity.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="group relative"
          >
            <div className="flex gap-5">
              <div className="flex flex-col items-center">
                <div className="relative">
                  <div className="w-12 h-12 rounded-[1.25rem] bg-slate-50 border border-slate-100 flex items-center justify-center overflow-hidden group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-sm">
                    <User className="w-6 h-6 text-[#2D5A27]/40" />
                  </div>
                  {/* Status Indicator Dot */}
                  <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center shadow-sm ${
                    activity.status === 'Completed' ? 'bg-green-500' :
                    activity.status === 'In Transit' ? 'bg-[#E9C46A]' :
                    activity.status === 'Delayed' ? 'bg-red-500' : 'bg-slate-300'
                  }`}>
                    {activity.status === 'Completed' ? <CheckCircle2 className="w-2 h-2 text-white" /> : 
                     activity.status === 'Delayed' ? <AlertCircle className="w-2 h-2 text-white" /> : null}
                  </div>
                </div>
                {i !== activities.length - 1 && (
                  <div className="w-px flex-1 bg-slate-100 my-4 group-hover:bg-[#2D5A27]/20 transition-colors" />
                )}
              </div>

              <div className="flex-1 pb-4">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-[10px] font-black text-[#2D5A27] uppercase tracking-[0.15em]">{activity.time}</div>
                  <ArrowRight className="w-3 h-3 text-slate-200 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </div>
                <h4 className="text-xs font-bold text-slate-800 leading-snug group-hover:text-[#2D5A27] transition-colors">
                  <span className="font-black text-slate-900">{activity.user}</span> {activity.action}
                </h4>
                <div className="mt-2 flex items-center gap-2">
                   <div className={`px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest ${
                     activity.status === 'Completed' ? 'bg-green-50 text-green-600' :
                     activity.status === 'In Transit' ? 'bg-amber-50 text-amber-600' :
                     activity.status === 'Delayed' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-400'
                   }`}>
                     {activity.status}
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-8 bg-slate-50/50 border-t border-slate-100 shrink-0">
        <button className="w-full py-4 rounded-2xl bg-white border border-slate-200 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:bg-slate-100 hover:text-slate-600 transition-all shadow-sm flex items-center justify-center gap-2 group">
          View Detailed Audit Log
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}
