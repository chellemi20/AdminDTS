import React, { useState } from 'react';
import { Upload, MapPin, Clock, ArrowRight, ShieldCheck, BadgeCheck } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function SubmitDocument() {
  const [priority, setPriority] = useState<'Low' | 'High' | 'Urgent'>('Low');
  const [fileName, setFileName] = useState('');

  return (
    <div className="bg-white rounded-[12px] border border-gray-100 shadow-sm overflow-hidden flex flex-col">
      <div className="bg-[#2D5A27] px-6 py-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
          <h3 className="font-bold text-sm uppercase tracking-wider">Submit New Document</h3>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full border border-white/20">
          <BadgeCheck className="w-3 h-3 text-[#D4AF37]" />
          <span className="text-[10px] font-bold uppercase tracking-tighter">Secure Server: Active</span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Upload Area */}
        <div className="relative group">
          <input 
            type="file" 
            onChange={(e) => setFileName(e.target.files?.[0]?.name || '')}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
          <div className="w-full px-5 py-8 bg-[#F8F9FA] border-2 border-dashed border-gray-200 rounded-[12px] flex flex-col items-center justify-center gap-3 group-hover:border-[#2D5A27] transition-all">
            <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-sm">
              <Upload className="w-6 h-6 text-[#2D5A27]" />
            </div>
            <p className="text-sm font-bold text-gray-500">
              {fileName ? <span className="text-[#2D5A27]">{fileName}</span> : 'Drag & drop file or click to browse'}
            </p>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">PDF, DOCX, or PNG (Max 25MB)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Destination */}
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Destination Department</label>
            <div className="relative">
              <select className="w-full appearance-none px-4 py-3 bg-[#F8F9FA] border border-gray-200 rounded-[12px] focus:outline-none focus:ring-2 focus:ring-[#2D5A27]/20 focus:border-[#2D5A27] font-bold text-sm text-gray-700 cursor-pointer">
                <option>Budget & Finance</option>
                <option>Regional Office</option>
                <option>Livestock Bureau</option>
                <option>Fisheries Division</option>
                <option>Infrastructure Office</option>
              </select>
              <MapPin className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>
          </div>

          {/* Duration */}
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Processing Duration</label>
            <div className="relative">
              <input 
                type="datetime-local" 
                className="w-full px-4 py-3 bg-[#F8F9FA] border border-gray-200 rounded-[12px] focus:outline-none focus:ring-2 focus:ring-[#2D5A27]/20 focus:border-[#2D5A27] font-bold text-sm text-gray-700"
              />
              <Clock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Priority Toggle */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Priority Status</label>
          <div className="flex gap-3">
            <button 
              onClick={() => setPriority('Low')}
              className={cn(
                "flex-1 py-3 rounded-[12px] text-xs font-black uppercase tracking-widest border-2 transition-all",
                priority === 'Low' ? "bg-blue-50 border-blue-500 text-blue-700" : "bg-white border-gray-100 text-gray-400 hover:border-blue-200"
              )}
            >
              Low
            </button>
            <button 
              onClick={() => setPriority('High')}
              className={cn(
                "flex-1 py-3 rounded-[12px] text-xs font-black uppercase tracking-widest border-2 transition-all",
                priority === 'High' ? "bg-orange-50 border-orange-500 text-orange-700" : "bg-white border-gray-100 text-gray-400 hover:border-orange-200"
              )}
            >
              High
            </button>
            <button 
              onClick={() => setPriority('Urgent')}
              className={cn(
                "flex-1 py-3 rounded-[12px] text-xs font-black uppercase tracking-widest border-2 transition-all",
                priority === 'Urgent' ? "bg-red-50 border-red-500 text-red-700" : "bg-white border-gray-100 text-gray-400 hover:border-red-200"
              )}
            >
              Urgent
            </button>
          </div>
        </div>

        <button className="w-full py-4 bg-[#2D5A27] text-white rounded-[12px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-[#23471f] transition-all group shadow-lg shadow-[#2D5A27]/20">
          Route Document
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}
