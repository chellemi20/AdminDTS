import React, { useState, useEffect } from 'react';
import { 
  Search, Filter, Eye, Download, ArrowRight, 
  CheckCircle, XCircle, Clock, FileText, ChevronRight 
} from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast'; // Mahalaga para sa notifications
import { DocumentApprovalModal } from './DocumentApprovalModal'; // Siguraduhing nagawa mo na ang file na ito
import { apiFetch, apiJson, fetchDocumentBlob } from '../lib/api';

interface Document {
  doc_id: number;
  tracking_number: string;
  title: string;
  category: string;
  destination: string;
  current_status: string;
  file_path: string;
  created_at: string;
  can_view?: boolean;
  requires_access_request?: boolean;
}

interface AccessRequest {
  request_id: number;
  doc_id: number;
  requester_id: number;
  reason?: string;
  requested_at: string;
  document_title: string;
  tracking_number: string;
}

export default function DocumentWorkflow({ currentUser }: { currentUser?: any }) {
  const [activeTab, setActiveTab] = useState<'incoming' | 'outgoing' | 'approvals'>('incoming');
  const [documents, setDocuments] = useState<Document[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [reviewDoc, setReviewDoc] = useState<Document | null>(null);
  const [accessRequests, setAccessRequests] = useState<AccessRequest[]>([]);
  const normalizedRole = String(currentUser?.role || '').toLowerCase().replace(/\s+/g, '');
  const department = String(currentUser?.department || '').toLowerCase();
  const isRecordsUser = normalizedRole === 'recordsstaff' || normalizedRole === 'records' || department.includes('records');

  // 1. FETCH DOCUMENTS FROM DATABASE
  const fetchDocuments = async () => {
    try {
      const data = await apiJson<Document[]>('/api/documents');
      setDocuments(data);
    } catch (error) {
      toast.error("Hindi makakonekta sa server.");
    }
  };

  useEffect(() => {
    fetchDocuments();
    apiJson<AccessRequest[]>('/api/access-requests/inbox')
      .then((rows) => setAccessRequests(rows || []))
      .catch(() => setAccessRequests([]));
  }, []);

  // 2. VIEW FILE (Fixed for spaces/special characters)
  const viewFile = async (doc: Document) => {
    try {
      const blob = await fetchDocumentBlob(doc.doc_id);
      const objectUrl = URL.createObjectURL(blob);
      window.open(objectUrl, '_blank', 'noopener,noreferrer');
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
    } catch (error: any) {
      if (error?.body?.requires_access_request) {
        toast.error('Access denied. Request access from the owner.');
      } else {
        toast.error(error?.message || "Walang file na nakita.");
      }
    }
  };

  const requestAccess = async (doc: Document) => {
    try {
      await apiJson(`/api/documents/${doc.doc_id}/access-requests`, {
        method: 'POST',
        body: JSON.stringify({ reason: 'Access needed for document review.' }),
      });
      toast.success('Access request sent to the document owner.');
      fetchDocuments();
    } catch (error: any) {
      toast.error(error?.message || 'Failed to send access request.');
    }
  };

  const decideRequest = async (requestId: number, decision: 'approve' | 'deny') => {
    try {
      await apiJson(
        `/api/access-requests/${requestId}/${decision === 'approve' ? 'approve' : 'deny'}`,
        {
          method: 'POST',
          body: JSON.stringify({
            decision_reason:
              decision === 'approve' ? 'Approved by document owner.' : 'Denied by document owner.',
          }),
        }
      );
      toast.success(`Request ${decision === 'approve' ? 'approved' : 'denied'}.`);
      const rows = await apiJson<AccessRequest[]>('/api/access-requests/inbox');
      setAccessRequests(rows || []);
    } catch (error: any) {
      toast.error(error?.message || 'Failed to update request.');
    }
  };

  // 3. UPDATE STATUS (For Transfer and Approval/Rejection)
  const onUpdateStatus = async (id: number, newStatus: string, comment: string = "", placement?: { x: number; y: number }) => {
    try {
      const response = await apiFetch(`/api/documents/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status: newStatus, comment: comment, signaturePosition: placement })
      });

      if (response.ok) {
        toast.success(`Document is now ${newStatus}`);
        fetchDocuments();
        setReviewDoc(null);
      } else {
        toast.error("Failed to update status. Check backend routes.");
      }
    } catch (error) {
      toast.error("Network error.");
    }
  };

  const onRecordsAction = async (id: number, newStatus: string, comment: string = "", placement?: { x: number; y: number }) => {
    try {
      await apiJson(`/api/documents/${id}/records-review`, {
        method: 'POST',
        body: JSON.stringify({
          action: newStatus === 'Rejected' ? 'reject' : 'approve',
          comment,
          stampPosition: placement,
        }),
      });
      toast.success(newStatus === 'Rejected' ? 'Records rejected the document.' : 'Document stamped received and sent for approval.');
      fetchDocuments();
      setReviewDoc(null);
    } catch (error: any) {
      toast.error(error?.message || 'Records review failed.');
    }
  };

  // Logic para sa Tabs
  const filteredDocs = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         doc.tracking_number.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'incoming') {
      return matchesSearch && (
        isRecordsUser
          ? doc.current_status === 'Records Review' || doc.current_status === 'Pending'
          : doc.current_status === 'For Review'
      );
    }
    if (activeTab === 'approvals') return matchesSearch && (doc.current_status === 'For Review' || doc.current_status === 'Approved' || doc.current_status === 'Rejected');
    if (activeTab === 'outgoing') return matchesSearch && !['Records Review', 'For Review'].includes(doc.current_status);
    return matchesSearch;
  });

  return (
    <div className="p-8 bg-[#F8FAFC] min-h-screen">
      <Toaster position="top-right" />
      
      <div className="mb-8">
        <h1 className="text-3xl font-black text-[#1E293B]">Document Workflow</h1>
        <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest mt-1">DA Administrative Management System</p>
      </div>

      {/* NAVIGATION TABS */}
      <div className="flex gap-4 mb-8 bg-white p-2 rounded-3xl shadow-sm w-fit border border-slate-100">
        {[
          { id: 'incoming', label: isRecordsUser ? 'Incoming Documents' : 'For Final Review' },
          { id: 'outgoing', label: 'Outgoing Documents' },
          { id: 'approvals', label: 'Approvals' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-8 py-4 rounded-[1.5rem] font-black text-[11px] uppercase tracking-wider transition-all
              ${activeTab === tab.id ? 'bg-[#2D5A27] text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* SEARCH BAR */}
      <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="p-8 border-b border-slate-50 flex justify-between items-center">
          <div className="relative w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search documents..."
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl text-sm outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* TABLE DATA */}
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Tracking ID</th>
              <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Document Title</th>
              <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Office</th>
              <th className="px-8 py-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filteredDocs.map((doc) => (
              <tr key={doc.doc_id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-8 py-6 font-black text-[11px] text-green-700 uppercase">{doc.tracking_number}</td>
                <td className="px-8 py-6">
                  <div className="font-black text-slate-700 text-[13px] uppercase">{doc.title}</div>
                  <div className="text-[9px] font-black text-green-500 uppercase">{doc.category}</div>
                </td>
                <td className="px-8 py-6 text-[11px] font-bold text-slate-500 uppercase">{doc.destination}</td>
                <td className="px-8 py-6">
                  <div className="flex items-center justify-end gap-3">
                    <button onClick={() => viewFile(doc)} className="p-2 text-slate-300 hover:text-green-600 transition-colors">
                      <Eye className="w-5 h-5" />
                    </button>
                    {doc.can_view === false && (
                      <button
                        onClick={() => requestAccess(doc)}
                        className="bg-blue-50 text-blue-600 px-4 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest"
                      >
                        Request Access
                      </button>
                    )}
                    
                    {/* BUTTONS BASED ON TAB */}
                    {activeTab === 'incoming' && isRecordsUser && (doc.current_status === 'Records Review' || doc.current_status === 'Pending') && (
                      <button 
                        onClick={() => setReviewDoc(doc)}
                        className="bg-[#E9C46A] text-[#7A5C12] px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-tighter shadow-md"
                      >
                        Receive & Stamp <ChevronRight className="inline w-3 h-3" />
                      </button>
                    )}

                    {(activeTab === 'incoming' || activeTab === 'approvals') && !isRecordsUser && doc.current_status === 'For Review' && (
                      <button 
                        onClick={() => setReviewDoc(doc)}
                        className="bg-[#2D5A27] text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-tighter"
                      >
                        Review & Decide
                      </button>
                    )}

                    {/* STATUS BADGES */}
                    {doc.current_status === 'Approved' && (
                      <span className="bg-green-50 text-green-600 px-4 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest">Approved</span>
                    )}
                    {doc.current_status === 'Rejected' && (
                      <span className="bg-red-50 text-red-600 px-4 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest">Rejected</span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* MODAL POPUP */}
      {reviewDoc && (
        <DocumentApprovalModal 
          doc={reviewDoc} 
          mode={isRecordsUser && (reviewDoc.current_status === 'Records Review' || reviewDoc.current_status === 'Pending') ? 'records' : 'approval'}
          onClose={() => setReviewDoc(null)} 
          onAction={(id, status, comment, placement) =>
            isRecordsUser && (reviewDoc.current_status === 'Records Review' || reviewDoc.current_status === 'Pending')
              ? onRecordsAction(id, status, comment, placement)
              : onUpdateStatus(id, status, comment, placement)
          } 
        />
      )}

      {accessRequests.length > 0 && (
        <div className="mt-6 bg-white rounded-3xl border border-slate-100 p-6">
          <h3 className="text-sm font-black text-slate-700 uppercase tracking-widest mb-4">
            Access Requests Inbox
          </h3>
          <div className="space-y-3">
            {accessRequests.map((request) => (
              <div
                key={request.request_id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-black text-slate-700">
                    {request.tracking_number} - {request.document_title}
                  </p>
                  <p className="text-[10px] text-slate-500 font-bold">
                    Requester ID: {request.requester_id} | {request.reason || 'No reason'}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => decideRequest(request.request_id, 'deny')}
                    className="px-3 py-2 rounded-lg bg-red-50 text-red-600 text-[10px] font-black uppercase"
                  >
                    Deny
                  </button>
                  <button
                    onClick={() => decideRequest(request.request_id, 'approve')}
                    className="px-3 py-2 rounded-lg bg-green-50 text-green-700 text-[10px] font-black uppercase"
                  >
                    Approve
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
