import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, ShieldCheck, Mail, Lock, CheckCircle, ArrowRight, X } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ResetPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
}

export function ResetPinModal({ isOpen, onClose, email }: ResetPinModalProps) {
  const [step, setStep] = useState<'otp' | 'reset' | 'success'>('otp');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const maskedEmail = email.replace(/(.{1})(.*)(@.*)/, "$1****$3");

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const verifyOtp = () => {
    setIsVerifying(true);
    // Simulate API verification
    setTimeout(() => {
      setIsVerifying(false);
      setStep('reset');
    }, 1500);
  };

  const handleReset = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStep('success');
    }, 1500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden relative"
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-300 hover:text-slate-600 transition-colors">
          <X className="w-6 h-6" />
        </button>

        <div className="p-10">
          <AnimatePresence mode="wait">
            {step === 'otp' && (
              <motion.div 
                key="otp"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-blue-100">
                    <Mail className="w-8 h-8 text-[#2D5A27]" />
                  </div>
                  <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">Verify Identity</h2>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-relaxed">
                    A 6-digit code was sent to <br />
                    <span className="text-[#2D5A27]">{maskedEmail}</span>
                  </p>
                </div>

                <div className="flex justify-between gap-2">
                  {otp.map((digit, i) => (
                    <input
                      key={i}
                      id={`otp-${i}`}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(i, e.target.value)}
                      className="w-12 h-16 text-center text-2xl font-black text-slate-800 bg-slate-50 border-2 border-slate-100 rounded-xl focus:border-[#2D5A27]/20 outline-none transition-all"
                    />
                  ))}
                </div>

                <button 
                  onClick={verifyOtp}
                  disabled={otp.some(d => !d) || isVerifying}
                  className="w-full py-5 rounded-2xl bg-[#2D5A27] text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-green-900/20 disabled:opacity-50 transition-all flex items-center justify-center gap-3"
                >
                  {isVerifying ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Verify & Proceed'}
                </button>
              </motion.div>
            )}

            {step === 'reset' && (
              <motion.div 
                key="reset"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-green-100">
                    <Shield className="w-8 h-8 text-[#2D5A27]" />
                  </div>
                  <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">Reset Your PIN</h2>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Create a new 6-digit signature PIN</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">New PIN</label>
                    <input 
                      type="password" 
                      maxLength={6}
                      placeholder="••••••"
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value)}
                      className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xl font-black tracking-[0.5em] focus:bg-white focus:border-[#2D5A27]/10 transition-all outline-none text-center placeholder:tracking-normal"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Confirm New PIN</label>
                    <input 
                      type="password" 
                      maxLength={6}
                      placeholder="••••••"
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value)}
                      className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xl font-black tracking-[0.5em] focus:bg-white focus:border-[#2D5A27]/10 transition-all outline-none text-center placeholder:tracking-normal"
                    />
                  </div>
                </div>

                <button 
                  onClick={handleReset}
                  disabled={newPin.length < 6 || newPin !== confirmPin || isVerifying}
                  className="w-full py-5 rounded-2xl bg-[#2D5A27] text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-green-900/20 disabled:opacity-50 transition-all flex items-center justify-center gap-3"
                >
                  {isVerifying ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Update Security PIN'}
                </button>
              </motion.div>
            )}

            {step === 'success' && (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center space-y-8"
              >
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto border-4 border-white shadow-xl">
                  <CheckCircle className="w-10 h-10 text-green-500 animate-bounce" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">PIN Updated!</h2>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Your signature security is now active</p>
                </div>
                <button 
                  onClick={onClose}
                  className="w-full py-5 rounded-2xl bg-[#2D5A27] text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-all"
                >
                  Continue to Portal
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
