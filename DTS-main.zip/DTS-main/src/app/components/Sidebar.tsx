import React from 'react';
import { 
  LayoutDashboard, 
  PieChart, 
  MessageSquare, 
  Settings, 
  Plus,
  FileText,
  UserCheck,
  Activity
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { BRAND_LOGO_URL, FALLBACK_LOGO_URL } from '../lib/brand';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// 1. Siguraduhin na ang 'STAFF' ay kasama at sakto ang spelling (All Caps)
const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', roles: ['AdminHead', 'Director', 'AdminStaff', 'AdminAssistant', 'STAFF', 'RecordsStaff'] },
  { icon: FileText, label: 'Workflows', roles: ['AdminHead', 'Director', 'AdminStaff', 'AdminAssistant', 'STAFF', 'RecordsStaff'] },
  { icon: PieChart, label: 'Reports', roles: ['AdminHead', 'Director', 'AdminStaff', 'AdminAssistant', 'STAFF', 'RecordsStaff'] },
  { icon: MessageSquare, label: 'Messages', roles: ['AdminHead', 'Director', 'AdminStaff', 'AdminAssistant', 'STAFF', 'RecordsStaff'] },
  { icon: UserCheck, label: 'Approval Account', roles: ['AdminHead', 'Director'] },
  { icon: Activity, label: 'Activity Logs', roles: ['SuperAdmin'] },
];

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onNewDocument: () => void;
  currentUser: any; // Idagdag ito kung wala pa
}

export function Sidebar({ activeTab, onTabChange, onNewDocument, currentUser }: SidebarProps) {
  const backend = 'http://localhost:5000';
  const [logoBroken, setLogoBroken] = React.useState(false);
  const normalizedRole = String(currentUser?.role || 'STAFF').toLowerCase().replace(/\s+/g, '');
  const isSuperAdmin = normalizedRole === 'superadmin';

  const resolveImage = (p: any) => {
    if (!p) return null;
    const s = String(p);
    if (s.startsWith('http') || s.startsWith('data:')) return s;
    if (s.startsWith('/')) return backend + s;
    return s;
  };

  return (
    <div className="w-72 h-screen bg-[#2D5A27] text-white flex flex-col sticky top-0 shrink-0 border-r border-white/5 shadow-2xl z-[100] sidebar-force-light">
      {/* Header / Logo Section */}
      <div className="p-8 flex flex-col gap-6">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => onTabChange('Dashboard')}>
          <div className="bg-white p-2 rounded-[12px] shadow-lg shadow-black/10 group-hover:rotate-12 transition-transform duration-500">
            {!logoBroken ? (
              <img
                src={BRAND_LOGO_URL}
                alt="DA Logo"
                className="w-10 h-10 object-contain"
                data-attempt="brand"
                onError={(e) => {
                  const img = e.currentTarget as HTMLImageElement;
                  if (img.dataset.attempt !== 'fallback') {
                    img.dataset.attempt = 'fallback';
                    img.src = FALLBACK_LOGO_URL;
                  } else {
                    setLogoBroken(true);
                  }
                }}
              />
            ) : (
              <div className="w-10 h-10 flex items-center justify-center bg-[#f1f5f9] text-sm font-black text-[#2D5A27] rounded">DA</div>
            )}
          </div>
          <div>
            <h1 className="font-black text-lg leading-tight tracking-tighter uppercase">
              Admin <span className="text-[#E9C46A]">Portal</span>
            </h1>
            <p className="text-[10px] text-white/60 font-bold uppercase tracking-widest leading-none">Document Tracking</p>
          </div>
        </div>
        <div className="h-px bg-white/10 w-full"></div>
      </div>

      {/* Main Actions & Nav */}
      <div className="px-4 py-2 flex-1 overflow-y-auto custom-scrollbar">
        {!isSuperAdmin && (
        <div className="px-4 mb-8">
          <button 
            onClick={onNewDocument}
            className="w-full flex items-center justify-center gap-3 bg-[#E9C46A] text-[#2D5A27] py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:bg-[#d4b35b] transition-all shadow-xl shadow-black/20 group active:scale-95 border-b-4 border-[#c9a64b]"
          >
            <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform duration-300" />
            New Document
          </button>
        </div>
        )}

        <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] px-4 mb-4">Main Navigation</p>
        <nav className="space-y-1">
          {navItems.map((item) => {
            // 2. LOGIC CHECK: Normalize role strings (case + spaces) so variants like
            //    "Admin Head" and "AdminHead" are treated the same.
            const normalize = (s: any) => String(s).toLowerCase().replace(/\s+/g, '');
            const userRole = normalizedRole;
            const allowedRoles = item.roles.map(normalize);
            const isAllowed = allowedRoles.includes(userRole);

            if (isAllowed) {
              return (
                <button
                  key={item.label}
                  onClick={() => onTabChange(item.label)}
                  className={cn(
                    "w-full flex items-center gap-4 px-4 py-4 transition-all duration-300 rounded-xl relative group text-left",
                    activeTab === item.label 
                      ? "bg-white/10 text-[#E9C46A]" 
                      : "text-white/50 hover:bg-white/5 hover:text-white"
                  )}
                >
                  {activeTab === item.label && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-[#E9C46A] rounded-r-full shadow-[0_0_15px_rgba(233,196,106,0.5)]"></div>
                  )}
                  <item.icon className={cn("w-5 h-5 transition-all duration-300", activeTab === item.label ? "text-[#E9C46A] scale-110" : "group-hover:text-white")} />
                  <span className="font-black text-[11px] uppercase tracking-widest">{item.label}</span>
                </button>
              );
            }
            return null;
          })}
        </nav>
      </div>

      {/* Profile Section */}
      <div className="p-6 space-y-4 bg-black/10">
        <button 
          onClick={() => onTabChange('Settings')}
          className={cn(
            "w-full flex items-center gap-4 px-4 py-3 transition-all duration-300 rounded-2xl relative group text-left border border-transparent",
            activeTab === 'Settings' 
              ? "bg-white/10 border-white/10 text-[#E9C46A]" 
              : "hover:bg-white/5 text-white/70"
          )}
        >
            <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-white/20 group-hover:border-[#E9C46A]/50 transition-colors shrink-0">
            <img
              src={resolveImage(currentUser?.profile_picture_path) || "https://images.unsplash.com/photo-1660081509826-a727cb918397?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"}
              alt="User Profile"
              className="w-full h-full object-cover"
              onError={(e) => { (e.currentTarget as HTMLImageElement).src = "https://images.unsplash.com/photo-1660081509826-a727cb918397?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"; }}
            />
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="text-[10px] font-black uppercase tracking-widest truncate">
              {currentUser?.full_name || "Rochelle Mae Bardaje"}
            </p>
            <p className="text-[8px] text-white/40 font-bold uppercase tracking-widest mt-0.5">
              {currentUser?.role || "Staff"}
            </p>
          </div>
          <Settings className={cn("w-4 h-4 opacity-40 group-hover:opacity-100 transition-opacity", activeTab === 'Settings' && "text-[#E9C46A] opacity-100")} />
        </button>

        <div className="bg-[#E9C46A]/10 rounded-[20px] p-4 border border-[#E9C46A]/20 group cursor-default">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 bg-[#E9C46A] rounded-full animate-pulse shadow-[0_0_8px_rgba(233,196,106,0.8)]"></div>
            <p className="text-[9px] text-[#E9C46A] font-black uppercase tracking-widest">System Online</p>
          </div>
          <p className="text-[10px] text-white/70 leading-tight font-medium group-hover:text-white transition-colors">
            Connected to Department of Agriculture Network.
          </p>
        </div>
      </div>
    </div>
  );
}
