import React from 'react';
import { motion } from 'framer-motion';
import { 
  CheckCircle, 
  Download, 
  Home, 
  QrCode, 
  ShieldCheck, 
  FileText,
  Share2,
  Printer,
  ChevronRight
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { BRAND_LOGO_URL } from '../lib/brand';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DocumentSuccessViewProps {
  documentId: string;
  userName: string;
  onReturn: () => void;
}

// Simple CSS-based Confetti Particles
const Confetti = () => {
  const colors = ['#1B5E20', '#4CAF50', '#81C784', '#FFD700', '#E9C46A'];
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-[4000]">
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            top: "-10%", 
            left: `${Math.random() * 100}%`, 
            opacity: 1,
            scale: Math.random() * 1 + 0.5,
            rotate: 0 
          }}
          animate={{ 
            top: "110%", 
            left: `${Math.random() * 100}%`,
            opacity: 0,
            rotate: 360 
          }}
          transition={{ 
            duration: Math.random() * 2 + 2, 
            repeat: Infinity, 
            ease: "linear",
            delay: Math.random() * 2
          }}
          className="absolute w-3 h-3 rounded-sm"
          style={{ backgroundColor: colors[Math.random() * colors.length | 0] }}
        />
      ))}
    </div>
  );
};

export function DocumentSuccessView({ documentId, userName, onReturn }: DocumentSuccessViewProps) {
  const timestamp = "MARCH 12, 2026 • 02:45 PM";
  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4 md:p-8 bg-slate-50/95 backdrop-blur-xl overflow-hidden">
      
      {/* Visual Celebration */}
      <Confetti />

      {/* Floating Success Banner */}
      <motion.div 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute top-0 left-0 right-0 bg-[#1B5E20] py-4 px-10 flex items-center justify-between shadow-2xl z-[3001]"
      >
        <div className="flex items-center gap-6">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex flex-col text-white">
            <h2 className="text-lg font-black uppercase tracking-tight">Document Signed Successfully</h2>
            <p className="text-green-200 text-[9px] font-bold uppercase tracking-[0.2em]">Department of Agriculture • Region IV-A</p>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-2 bg-white/10 px-5 py-2 rounded-full border border-white/10">
           <span className="text-[9px] font-black text-white uppercase tracking-widest">Routing to Central Office</span>
           <ChevronRight className="w-4 h-4 text-green-300" />
        </div>
      </motion.div>

      <motion.div 
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-5xl h-full max-h-[850px] flex flex-col gap-8 mt-12"
      >
        <div className="flex-1 bg-white rounded-[3.5rem] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] border border-slate-200 overflow-hidden flex flex-col relative">
            
            <div className="px-10 py-5 border-b border-slate-100 flex justify-between items-center bg-white">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tracking ID: {documentId}</span>
              </div>
              <div className="flex gap-2">
                <button className="p-2.5 text-slate-400 hover:bg-slate-50 rounded-xl transition-all"><Printer className="w-5 h-5" /></button>
                <button className="p-2.5 text-slate-400 hover:bg-slate-50 rounded-xl transition-all"><Share2 className="w-5 h-5" /></button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-12 bg-slate-50/50 custom-scrollbar flex justify-center">
              <div className="bg-white w-full max-w-[700px] shadow-sm rounded-sm p-16 relative border border-slate-100 min-h-[900px] flex flex-col">
                
                <div className="flex justify-between items-start opacity-30 mb-12">
                   <img src={BRAND_LOGO_URL} alt="DA" className="w-12 h-12 grayscale" />
                   <div className="text-right font-mono text-[9px]">HASH: 8F2D-DA-{documentId}</div>
                </div>

                <div className="space-y-6 flex-1">
                   <div className="h-3 w-3/4 bg-slate-50 rounded-full" />
                   <div className="h-3 w-full bg-slate-50 rounded-full" />
                   <div className="h-3 w-5/6 bg-slate-50 rounded-full" />
                </div>

                <div className="mt-auto relative py-12">
                  <motion.div 
                    initial={{ scale: 3, opacity: 0, rotate: 10 }}
                    animate={{ scale: 1, opacity: 1, rotate: -12 }}
                    transition={{ delay: 0.3, type: 'spring' }}
                    className="absolute -top-10 right-10 z-20"
                  >
                    <div className="border-[5px] border-[#1B5E20]/60 px-6 py-2 rounded-xl bg-white/80 backdrop-blur-sm shadow-xl">
                      <p className="text-4xl font-black text-[#1B5E20]/80 tracking-tighter leading-none">APPROVED</p>
                      <p className="text-[8px] font-black text-[#1B5E20]/80 text-center uppercase mt-1">Digital Signature Verified</p>
                    </div>
                  </motion.div>

                  <div className="grid grid-cols-2 gap-16 text-center">
                    <div className="pt-8 border-t border-slate-100">
                       <p className="text-xs font-black text-slate-400 uppercase tracking-widest">J. Dela Cruz</p>
                       <p className="text-[8px] font-bold text-slate-300 uppercase">Preparer</p>
                    </div>

                    <div className="pt-8 border-t-2 border-slate-900 relative">
                       <p className="absolute -top-10 left-0 right-0 text-2xl font-serif italic text-[#1B5E20] opacity-80">
                         {userName}
                       </p>
                       <p className="text-xs font-black text-slate-900 uppercase tracking-widest">{userName}</p>
                       <p className="text-[8px] font-bold text-slate-400 uppercase">Regional Director</p>
                       
                       <div className="mt-3 flex items-center justify-center gap-1.5 py-1 px-3 bg-green-50 rounded-full border border-green-100 w-max mx-auto">
                          <ShieldCheck className="w-3 h-3 text-green-600" />
                          <span className="text-[7px] font-black text-green-700 uppercase">Secure Hash Matched</span>
                       </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-8 border-t border-slate-50 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <QrCode className="w-8 h-8 text-slate-200" />
                      <div className="text-[7px] text-slate-300 font-medium uppercase tracking-tight">
                         Valid Electronic Document<br /> 
                         SEC-2026-REGION4A
                      </div>
                   </div>
                   <div className="text-right">
                      <p className="text-[7px] font-black text-slate-300 uppercase">Signed On</p>
                      <p className="text-[9px] font-mono font-bold text-slate-400">{timestamp}</p>
                   </div>
                </div>
              </div>
            </div>
        </div>

        <div className="flex items-center justify-center gap-5">
           <button className="flex items-center gap-3 px-12 py-5 bg-[#1B5E20] text-white rounded-3xl font-black text-[11px] uppercase tracking-[0.2em] shadow-2xl shadow-green-900/40 hover:bg-[#0E3A14] transition-all active:scale-95 group">
              <Download className="w-5 h-5 group-hover:animate-bounce" />
              Download Official Copy
           </button>
           <button 
             onClick={onReturn}
             className="flex items-center gap-3 px-12 py-5 bg-white text-[#1B5E20] border-2 border-slate-200 rounded-3xl font-black text-[11px] uppercase tracking-[0.2em] hover:bg-slate-50 transition-all active:scale-95"
           >
              <Home className="w-5 h-5" />
              Back to Dashboard
           </button>
        </div>
      </motion.div>
    </div>
  );
}
