import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, XCircle, User, Shield, IdCard, Calendar } from 'lucide-react';

export type PendingUser = {
  id: string;
  name: string;
  email: string;
  employeeId: string;
  role: string;
  requestedAt: string;
};

interface UserManagementProps {
  pendingUsers: PendingUser[];
  onApprove: (userId: string) => void;
  onReject: (userId: string) => void;
  activeAccounts: Array<{ name: string; email: string; role: string; employeeId: string }>;
}

export function UserManagement({ pendingUsers, onApprove, onReject, activeAccounts }: UserManagementProps) {
  return (
    <div className="space-y-8">
      {/* Pending Approvals */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center">
            <Shield className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <h3 className="text-xl font-black text-gray-900">Registration Approvals</h3>
            <p className="text-sm text-gray-500 font-medium">New personnel waiting for system authorization</p>
          </div>
        </div>

        {pendingUsers.length === 0 ? (
          <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-3xl p-8 text-center text-gray-400">
             <p className="font-bold">No pending registrations at the moment.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {pendingUsers.map((user) => (
              <motion.div 
                key={user.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm flex items-center justify-between group hover:shadow-md transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gray-50 flex items-center justify-center border border-gray-100">
                    <User className="w-7 h-7 text-gray-400" />
                  </div>
                  <div>
                    <h4 className="font-black text-gray-900 text-lg">{user.name}</h4>
                    <div className="flex items-center gap-4 text-xs font-bold mt-1">
                      <span className="flex items-center gap-1.5 text-gray-400">
                        <IdCard className="w-3.5 h-3.5" />
                        {user.employeeId}
                      </span>
                      <span className="flex items-center gap-1.5 text-[#2D5A27] bg-[#2D5A27]/5 px-2 py-0.5 rounded-full">
                        {user.role}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => onReject(user.id)}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-black text-sm text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                  <button 
                    onClick={() => onApprove(user.id)}
                    className="flex items-center gap-2 px-6 py-2.5 bg-[#2D5A27] text-white rounded-xl font-black text-sm shadow-lg shadow-[#2D5A27]/20 hover:bg-[#23471f] transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve Access
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Active Accounts */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <User className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-xl font-black text-gray-900">System Accounts</h3>
            <p className="text-sm text-gray-500 font-medium">Currently authorized departmental personnel</p>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Personnel</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Employee ID</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Role</th>
                <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {activeAccounts.map((account, idx) => (
                <tr key={idx} className="hover:bg-gray-50/50 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center text-[#2D5A27] font-black">
                        {account.name[0]}
                      </div>
                      <div>
                        <p className="font-black text-gray-900">{account.name}</p>
                        <p className="text-xs text-gray-400 font-medium">{account.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className="font-mono text-xs font-bold text-gray-500">{account.employeeId}</span>
                  </td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1 bg-gray-100 rounded-lg text-xs font-black text-gray-600">{account.role}</span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 rounded-full bg-green-500"></div>
                       <span className="text-xs font-black text-gray-900">Active</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
