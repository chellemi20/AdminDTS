import React, { useEffect, useState } from 'react';
import { Check, X, User, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { apiJson } from '../lib/api';

export function ApprovalPage() {
  const [pendingUsers, setPendingUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [confirmModal, setConfirmModal] = useState<{ open: boolean; userId?: number | null; action?: 'Approved' | 'Rejected' | null; userName?: string }>({ open: false, userId: null, action: null, userName: '' });

  // 1. Fetch pending users mula sa database
  const fetchPendingUsers = async () => {
    try {
      const data = await apiJson<any[]>('/api/admin/pending-users');
      setPendingUsers(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching users:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPendingUsers();
  }, []);

  // 2. Function para sa Approve/Reject
  const handleAction = async (userId: number, action: 'Approved' | 'Rejected', userName?: string) => {
    try {
      await apiJson('/api/admin/update-status', {
        method: 'PUT',
        body: JSON.stringify({ userId, newStatus: action }),
      });
      if (action === 'Approved') {
        toast.success(`${userName || 'The user'} has been successfully approved. The account is now active and the user may sign in.`);
      } else {
        toast('The account has been rejected. If you require further details, please contact the administrative office.', { description: `${userName || 'The user'}'s registration was declined.` });
      }
      // Refresh the list after action
      fetchPendingUsers();
    } catch (error: any) {
      toast.error(`Failed to update user status: ${error?.message || String(error)}`);
    }
  };

  const openConfirm = (userId: number, action: 'Approved' | 'Rejected', userName?: string) => {
    setConfirmModal({ open: true, userId, action, userName: userName || '' });
  };

  const closeConfirm = () => setConfirmModal({ open: false, userId: null, action: null, userName: '' });

  const confirmAndExecute = async () => {
    if (!confirmModal.userId || !confirmModal.action) return closeConfirm();
    await handleAction(confirmModal.userId, confirmModal.action, confirmModal.userName);
    closeConfirm();
  };

  return (
    <div className="p-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-[#E9C46A]/20 p-3 rounded-2xl">
          <ShieldCheck className="w-8 h-8 text-[#E9C46A]" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-[#2D5A27] uppercase tracking-tighter">Account Approvals</h2>
          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Pending Personnel Verification</p>
        </div>
      </div>

      <div className="bg-white rounded-[32px] shadow-xl shadow-black/5 border border-gray-100 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50/50">
              <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100">Personnel</th>
              <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100">Designation</th>
              <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100">Employee ID</th>
              <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 border-b border-gray-100 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {pendingUsers.length === 0 ? (
              <tr>
                <td colSpan={4} className="p-20 text-center">
                  <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No pending accounts for approval</p>
                </td>
              </tr>
            ) : (
              pendingUsers.map((user: any) => (
                <tr key={user.user_id} className="hover:bg-gray-50/50 transition-colors group">
                  <td className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-gray-400 group-hover:bg-[#2D5A27]/10 group-hover:text-[#2D5A27] transition-colors">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-black text-sm text-gray-800 uppercase tracking-tight">{user.full_name}</p>
                        <p className="text-[10px] text-gray-400 font-medium">{user.email_address}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100">
                      {user.role}
                    </span>
                    <p className="text-[10px] text-gray-400 mt-1 font-bold uppercase">{user.department}</p>
                  </td>
                  <td className="p-6 font-mono text-xs text-gray-500">{user.employee_id}</td>
                  <td className="p-6">
                    <div className="flex justify-center gap-2">
                      <button 
                        onClick={() => openConfirm(user.user_id, 'Approved', user.full_name)}
                        className="p-3 bg-green-50 text-green-600 rounded-xl hover:bg-green-600 hover:text-white transition-all shadow-sm active:scale-95"
                        title="Approve Account"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => openConfirm(user.user_id, 'Rejected', user.full_name)}
                        className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm active:scale-95"
                        title="Reject Account"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {/* Confirmation Modal */}
      {confirmModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6">
            <h3 className="text-lg font-black text-[#2D5A27] mb-2">{confirmModal.action === 'Approved' ? 'Confirm Approval' : 'Confirm Rejection'}</h3>
            <p className="text-sm text-gray-600 mb-6">
              {confirmModal.action === 'Approved'
                ? `You are about to approve the account for ${confirmModal.userName || 'this user'}. This will activate their access to the system.`
                : `You are about to reject the account for ${confirmModal.userName || 'this user'}. This will decline the registration request.`}
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={closeConfirm} className="px-4 py-2 rounded-lg border font-bold">Cancel</button>
              <button onClick={confirmAndExecute} className="px-4 py-2 rounded-lg bg-[#2D5A27] text-white font-black">Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}