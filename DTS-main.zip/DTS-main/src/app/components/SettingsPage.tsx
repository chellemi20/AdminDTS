import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion'; // Gamitin ang framer-motion
import toast from 'react-hot-toast';
import { 
  User, 
  Lock, 
  Bell, 
  Palette, 
  Shield, 
  Save, 
  Camera, 
  Mail, 
  Smartphone,
  ShieldCheck,
  Moon,
  Sun,
  LogOut
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { apiJson, backendUrl, clearAuthSession } from '../lib/api';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// 1. Tanggapin ang currentUser bilang PROPS
interface SettingsPageProps {
  currentUser: any;
}

export function SettingsPage({ currentUser }: SettingsPageProps) {
  const [activeSection, setActiveSection] = useState('profile');
  // 'light' | 'dark' | 'system'
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('light');
  const [signatureImage, setSignatureImage] = useState<string | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [backups, setBackups] = useState<any[]>([]);
  const [isBackupRunning, setIsBackupRunning] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    system: true,
    delayed: true,
    incoming: false
  });
  const BACKEND_URL = 'http://localhost:5000';
  const normalizedRole = String(currentUser?.role || '').toLowerCase().replace(/\s+/g, '');
  const canRunBackups = normalizedRole === 'adminhead' || normalizedRole === 'director';

  const handleSignatureUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (readerEvent) => {
          setSignatureImage(readerEvent.target?.result as string);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleProfileUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (readerEvent) => {
          setProfileImage(readerEvent.target?.result as string);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  // 2. LOGOUT FUNCTION
  const handleLogout = () => {
    clearAuthSession();
    window.location.reload();
  };

  // Load persisted settings and apply theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('dts_theme');
    const savedNotif = localStorage.getItem('dts_notifications');
    if (savedTheme === 'light' || savedTheme === 'dark' || savedTheme === 'system') setTheme(savedTheme as any);
    if (savedNotif) {
      try { setNotifications(JSON.parse(savedNotif)); } catch (e) { /* ignore */ }
    }

    const applyTheme = (t: string) => {
      const root = document.documentElement;
      if (t === 'dark') root.classList.add('dark');
      else if (t === 'light') root.classList.remove('dark');
      else {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDark) root.classList.add('dark'); else root.classList.remove('dark');
      }
    };

    applyTheme(savedTheme || 'system');

    const mq = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
    const mqHandler = () => {
      const currentTheme = localStorage.getItem('dts_theme') || 'system';
      if (currentTheme === 'system') applyTheme('system');
    };
    if (mq && mq.addEventListener) mq.addEventListener('change', mqHandler);
    else if (mq && mq.addListener) mq.addListener(mqHandler as any);

    return () => {
      if (mq && mq.removeEventListener) mq.removeEventListener('change', mqHandler);
      else if (mq && mq.removeListener) mq.removeListener(mqHandler as any);
    };
  }, []);

  // Sync theme state to document and localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else if (theme === 'light') root.classList.remove('dark');
    else {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) root.classList.add('dark'); else root.classList.remove('dark');
    }
    localStorage.setItem('dts_theme', theme);
  }, [theme]);

  useEffect(() => {
    if (!canRunBackups) return;
    apiJson<any[]>('/api/admin/backups')
      .then((rows) => setBackups(rows || []))
      .catch(() => setBackups([]));
  }, [canRunBackups]);

  const saveSettings = () => {
    (async () => {
      // 1) If changing password (security section), attempt password update first
      if ((newPin || confirmPin) && activeSection === 'security') {
        if (!newPin || !confirmPin) { toast.error('Please enter and confirm new password'); return; }
        if (newPin !== confirmPin) { toast.error('Passwords do not match'); return; }
        if (String(newPin).length < 6) { toast.error('Password must be at least 6 characters'); return; }

        // find user id
        let user = currentUser;
        if (!user) {
          const uj = localStorage.getItem('user');
          if (uj) { try { user = JSON.parse(uj); } catch (e) { user = null; } }
        }
        if (!user || !user.user_id) { toast.error('Cannot change password: not signed in'); return; }

        try {
          const j = await apiJson<{ success: boolean }>(`/api/users/${user.user_id}/password`, {
            method: 'PUT',
            body: JSON.stringify({ currentPassword: '', newPassword: newPin }),
          });
          if (j && j.success) {
            toast.success('Password updated');
            setNewPin(''); setConfirmPin('');
          } else {
            toast.error('Failed to update password');
            return;
          }
        } catch (e) {
          console.error('Password update error:', e);
          toast.error('Password update failed. Is backend running?');
          return;
        }
      }

      // 2) Save theme & notifications
      localStorage.setItem('dts_theme', theme);
      localStorage.setItem('dts_notifications', JSON.stringify(notifications));
      // notify other parts of the app to apply the theme immediately
      try { window.dispatchEvent(new CustomEvent('dts-theme-changed', { detail: theme })); }
      catch (e) { /* ignore */ }
      toast.success('Settings saved');
    })();
  };

  // upload profile and signature when they change (and user is known)
  useEffect(() => {
    const uploadIfNeeded = async () => {
      // prefer currentUser prop (provided by App) but fallback to localStorage for compatibility
      let user = currentUser;
      if (!user) {
        const userJson = localStorage.getItem('user');
        if (userJson) {
          try { user = JSON.parse(userJson); } catch (e) { user = null; }
        }
      }
      if (!user || !user.user_id) {
        // show helpful message so user knows why save didn't happen
        if (signatureImage || profileImage) {
          toast.error('Cannot save: you are not signed in. Please login and try again.');
        }
        return;
      }
      const id = user.user_id;

      try {
        if (profileImage && profileImage.startsWith('data:')) {
          const filename = `profile_${Date.now()}.png`;
          const j = await apiJson<{ path?: string }>(`/api/users/${id}/upload-profile`, {
            method: 'POST',
            body: JSON.stringify({ filename, data: profileImage }),
          });
          if (j && j.path) {
            user.profile_picture_path = j.path;
            localStorage.setItem('user', JSON.stringify(user));
            try { window.dispatchEvent(new CustomEvent('dts-user-updated', { detail: user })); } catch (e) {}
            toast.success('Profile image saved');
          } else {
            toast.error('Failed to save profile image');
          }
        }

        if (signatureImage && signatureImage.startsWith('data:')) {
          const filename = `signature_${Date.now()}.png`;
          const j = await apiJson<{ path?: string }>(`/api/users/${id}/upload-signature`, {
            method: 'POST',
            body: JSON.stringify({ filename, data: signatureImage }),
          });
          if (j && j.path) {
            user.signature_path = j.path;
            localStorage.setItem('user', JSON.stringify(user));
            try { window.dispatchEvent(new CustomEvent('dts-user-updated', { detail: user })); } catch (e) {}
            toast.success('Digital signature saved');
          } else {
            toast.error('Failed to save signature');
          }
        }
      } catch (e) {
        console.error('Upload error:', e);
        toast.error('Upload error. Check backend server.');
      }
    };

    uploadIfNeeded();
  }, [profileImage, signatureImage, currentUser]);

  // When currentUser changes (for example after save), load persisted image paths
  useEffect(() => {
    if (!currentUser) return;
    // Backend serves images under /uploads — make absolute URL to backend
    const backend = BACKEND_URL;
    if (currentUser.signature_path) {
      // if it's already a data URL, keep it
      if (String(currentUser.signature_path).startsWith('data:')) {
        setSignatureImage(currentUser.signature_path);
      } else {
        setSignatureImage(backend + currentUser.signature_path);
      }
    }
    if (currentUser.profile_picture_path) {
      if (String(currentUser.profile_picture_path).startsWith('data:')) {
        setProfileImage(currentUser.profile_picture_path);
      } else {
        setProfileImage(backend + currentUser.profile_picture_path);
      }
    }
  }, [currentUser]);

  // Manual upload trigger for signature (visible Save button)
  const uploadSignatureNow = async () => {
    let user = currentUser;
    if (!user) {
      const userJson = localStorage.getItem('user');
      if (userJson) {
        try { user = JSON.parse(userJson); } catch (e) { user = null; }
      }
    }
    if (!user || !user.user_id) {
      toast.error('Cannot save: you are not signed in. Please login and try again.');
      return;
    }

    if (!signatureImage || !signatureImage.startsWith('data:')) {
      toast.error('No signature selected. Click the box to upload an image first.');
      return;
    }

    const id = user.user_id;
    try {
      toast.loading('Saving signature...');
      const filename = `signature_${Date.now()}.png`;
      const j = await apiJson<{ path?: string }>(`/api/users/${id}/upload-signature`, {
        method: 'POST',
        body: JSON.stringify({ filename, data: signatureImage }),
      });
      toast.dismiss();
      if (j && j.path) {
        user.signature_path = j.path;
        localStorage.setItem('user', JSON.stringify(user));
        try { window.dispatchEvent(new CustomEvent('dts-user-updated', { detail: user })); } catch (e) {}
        // immediately show the saved signature image
        try {
          const imgPath = backendUrl(j.path);
          setSignatureImage(imgPath);
        } catch (_) {}
        toast.success('Digital signature saved');
      } else {
        console.error('Signature save failed response:', j);
        toast.error('Failed to save signature');
      }
    } catch (e) {
      toast.dismiss();
      console.error('Upload signature error:', e);
      toast.error('Upload error. Is the backend running?');
    }
  };

  const sections = [
    { id: 'profile', label: 'Profile Information', icon: User },
    { id: 'security', label: 'Account Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'theme', label: 'Theme Settings', icon: Palette },
    ...(canRunBackups ? [{ id: 'backup', label: 'Backup Center', icon: ShieldCheck }] : []),
  ];

  return (
    <div className={cn(
      "max-w-[1200px] mx-auto space-y-10 animate-in fade-in duration-500 pb-20"
    )}>

      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Account & Profile</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-1">Manage your DA identity and security</p>
        </div>
        <button 
          onClick={handleLogout}
          className="flex items-center gap-2 px-6 py-3 bg-red-50 text-red-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-100 transition-all border border-red-100"
        >
          <LogOut className="w-4 h-4" />
          Logout Account
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10 items-start">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={cn(
                "w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-300 text-left group relative",
                activeSection === section.id
                  ? "bg-white shadow-xl shadow-slate-200/50 text-[#2D5A27]"
                  : "text-slate-400 hover:bg-white/50 hover:text-slate-600"
              )}
            >
              {activeSection === section.id && (
                <motion.div layoutId="active-indicator" className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-[#2D5A27] rounded-r-full" />
              )}
              <section.icon className={cn("w-5 h-5", activeSection === section.id ? "text-[#2D5A27]" : "group-hover:text-slate-600")} />
              <span className="text-xs font-black uppercase tracking-widest">{section.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="lg:col-span-3 bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-50 overflow-hidden min-h-[600px] flex flex-col">
          <div className="p-10 flex-1 space-y-10">
            {activeSection === 'profile' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-10">
                <div className="flex flex-col items-center sm:flex-row gap-8">
                  <div className="relative group">
                    <div className="w-32 h-32 rounded-[2rem] overflow-hidden border-4 border-slate-50 shadow-2xl">
                      <img 
                        src={profileImage || currentUser?.profile_picture_path || "https://images.unsplash.com/photo-1660081509826-a727cb918397?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"} 
                        alt="Profile" 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <button onClick={handleProfileUpload} className="absolute -bottom-2 -right-2 p-3 bg-[#2D5A27] text-white rounded-xl shadow-xl hover:scale-110 transition-transform">
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="space-y-2 text-center sm:text-left">
                    {/* DYNAMIC NAME & ROLE */}
                    <h2 className="text-2xl font-black text-slate-800 tracking-tight">{currentUser?.full_name || "New Personnel"}</h2>
                    <p className="text-[10px] font-black text-[#2D5A27] uppercase tracking-[0.2em] bg-green-50 px-3 py-1.5 rounded-full w-fit mx-auto sm:mx-0">
                      {currentUser?.role || "Staff"}
                    </p>
                    <div className="flex flex-wrap justify-center sm:justify-start gap-4 mt-4">
                      <div className="flex flex-col">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Employee ID</span>
                        <span className="text-xs font-black text-slate-600">{currentUser?.employee_id || "N/A"}</span>
                      </div>
                      <div className="w-px h-8 bg-slate-100" />
                      <div className="flex flex-col">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Department</span>
                        <span className="text-xs font-black text-slate-600">{currentUser?.department || "General Services"}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-50">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                      <input 
                        type="email" 
                        readOnly
                        value={currentUser?.email_address || currentUser?.username || ""} 
                        className="w-full pl-12 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xs font-bold text-slate-500 outline-none" 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Phone Number</label>
                    <div className="relative">
                      <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                      <input type="tel" defaultValue="+63 912 345 6789" className="w-full pl-12 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xs font-bold focus:bg-white focus:border-[#2D5A27]/10 transition-all outline-none" />
                    </div>
                  </div>
                </div>

                {/* Digital Signature Section */}
                <div className="p-6 bg-[#2D5A27]/5 rounded-3xl border border-[#2D5A27]/10">
                  <h4 className="text-xs font-black text-[#2D5A27] uppercase tracking-widest mb-4">Digital Signature</h4>
                  <div 
                    onClick={handleSignatureUpload}
                    className="h-32 bg-white border-2 border-dashed border-[#2D5A27]/20 rounded-2xl flex flex-col items-center justify-center gap-2 group cursor-pointer hover:bg-slate-50 transition-all overflow-hidden relative"
                  >
                    {signatureImage ? (
                      <div className="w-full h-full flex items-center justify-center p-4 bg-white relative">
                         <img src={signatureImage} alt="Uploaded Signature" className="max-h-full object-contain mix-blend-multiply" />
                         <div className="absolute inset-0 bg-black/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                            <span className="bg-white/90 px-3 py-1 rounded-full text-[8px] font-black text-[#2D5A27] uppercase tracking-widest">Change Signature</span>
                         </div>
                      </div>
                    ) : (
                      <>
                        <div className="p-3 bg-green-50 rounded-full text-[#2D5A27] group-hover:scale-110 transition-transform">
                          <Camera className="w-5 h-5" />
                        </div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Upload scanned signature for approvals</p>
                      </>
                    )}
                  </div>
                    <div className="mt-4 flex justify-end">
                      <button onClick={uploadSignatureNow} className="px-6 py-3 bg-[#2D5A27] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-[#23471f] transition-all">
                        Save Signature
                      </button>
                    </div>
                </div>
              </motion.div>
            )}

            {/* Iba pang sections gaya ng Security, Notifications, Theme (Idagdag dito kung kailangan) */}
            {activeSection === 'security' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
                 <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-3">
                   <Lock className="w-4 h-4 text-[#2D5A27]" />
                   Password Security
                 </h3>
                 <div className="max-w-md space-y-4">
                    <input type="password" placeholder="Current Password" className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xs font-bold focus:border-[#2D5A27]/10 outline-none" />
                    <input type="password" placeholder="New Password" className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl text-xs font-bold focus:border-[#2D5A27]/10 outline-none" />
                 </div>
              </motion.div>
            )}

            {activeSection === 'theme' && (
              <div className="grid grid-cols-2 gap-4">
                <button onClick={() => setTheme('light')} className={cn("p-6 rounded-3xl border-2 transition-all flex flex-col items-start", theme === 'light' ? "border-[#2D5A27] bg-green-50" : "border-slate-100")}>
                  <Sun className="w-8 h-8 mb-2 text-[#2D5A27]" />
                  <p className="text-xs font-black uppercase tracking-widest">Light</p>
                </button>
                <button onClick={() => setTheme('dark')} className={cn("p-6 rounded-3xl border-2 transition-all flex flex-col items-start", theme === 'dark' ? "border-[#E9C46A] bg-slate-800" : "border-slate-100")}>
                  <Moon className="w-8 h-8 mb-2 text-[#E9C46A]" />
                  <p className="text-xs font-black uppercase tracking-widest">Dark</p>
                </button>
              </div>
            )}

            {activeSection === 'notifications' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 max-w-xl">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-3">
                  <Bell className="w-4 h-4 text-[#2D5A27]" />
                  Notification Preferences
                </h3>
                <div className="space-y-4">
                  <label className="flex items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <div className="text-xs font-black">Allow Email Notifications</div>
                      <div className="text-[10px] text-slate-400">Receive notifications via email</div>
                    </div>
                    <input type="checkbox" checked={notifications.email} onChange={(e) => setNotifications(prev => ({ ...prev, email: e.target.checked }))} />
                  </label>

                  <label className="flex items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <div className="text-xs font-black">System Notifications</div>
                      <div className="text-[10px] text-slate-400">In-app notification banners</div>
                    </div>
                    <input type="checkbox" checked={notifications.system} onChange={(e) => setNotifications(prev => ({ ...prev, system: e.target.checked }))} />
                  </label>

                  <label className="flex items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <div className="text-xs font-black">Delayed Notifications</div>
                      <div className="text-[10px] text-slate-400">Notify about delayed items</div>
                    </div>
                    <input type="checkbox" checked={notifications.delayed} onChange={(e) => setNotifications(prev => ({ ...prev, delayed: e.target.checked }))} />
                  </label>

                  <label className="flex items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <div className="text-xs font-black">Incoming Document Alerts</div>
                      <div className="text-[10px] text-slate-400">Alerts for newly routed documents</div>
                    </div>
                    <input type="checkbox" checked={notifications.incoming} onChange={(e) => setNotifications(prev => ({ ...prev, incoming: e.target.checked }))} />
                  </label>
                </div>
              </motion.div>
            )}

            {activeSection === 'backup' && canRunBackups && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-3">
                  <ShieldCheck className="w-4 h-4 text-[#2D5A27]" />
                  One-Click Backup
                </h3>
                <button
                  onClick={async () => {
                    try {
                      setIsBackupRunning(true);
                      await apiJson('/api/admin/backups/run', { method: 'POST', body: JSON.stringify({}) });
                      const rows = await apiJson<any[]>('/api/admin/backups');
                      setBackups(rows || []);
                      toast.success('Backup completed successfully');
                    } catch (error: any) {
                      toast.error(error?.message || 'Backup failed');
                    } finally {
                      setIsBackupRunning(false);
                    }
                  }}
                  className="px-6 py-4 bg-[#2D5A27] text-white rounded-2xl text-xs font-black uppercase tracking-widest disabled:opacity-50"
                  disabled={isBackupRunning}
                >
                  {isBackupRunning ? 'Running Backup...' : 'Run One-Click Backup'}
                </button>
                <div className="space-y-2">
                  {backups.map((b) => (
                    <div key={b.backup_id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-[10px]">
                      <p className="font-black text-slate-700">
                        Backup #{b.backup_id} - {b.status}
                      </p>
                      <p className="text-slate-500">{b.archive_path || 'No archive yet'}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Action Bar */}
          <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-4">
            <button onClick={saveSettings} className="px-10 py-4 rounded-2xl bg-[#2D5A27] text-white text-xs font-black uppercase tracking-[0.2em] shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3">
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}