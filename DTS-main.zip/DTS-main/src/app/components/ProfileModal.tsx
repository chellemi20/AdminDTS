import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Phone, Calendar, Shield, MapPin, Edit2 } from 'lucide-react';

interface UserProfile {
  name: string;
  role: string;
  email: string;
  phone: string;
  birthday: string;
  employeeId: string;
}

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  userImage: string;
}

export function ProfileModal({ isOpen, onClose, user, userImage }: ProfileModalProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white w-full max-w-2xl rounded-[3.5rem] shadow-2xl overflow-hidden border border-white/20"
        >
          {/* Cover Area */}
          <div className="h-40 bg-[#2D5A27] relative">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
            <button 
              onClick={onClose}
              className="absolute top-8 right-8 p-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition-colors backdrop-blur-md"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Profile Header */}
          <div className="px-12 pb-12 relative">
            <div className="relative -mt-20 mb-8 flex justify-between items-end">
              <div className="relative">
                <img 
                  src={userImage} 
                  alt={user.name} 
                  className="w-40 h-40 rounded-[3rem] object-cover border-8 border-white shadow-lg shadow-black/5"
                />
                <div className="absolute -bottom-2 -right-2 bg-green-500 w-8 h-8 border-4 border-white rounded-full"></div>
              </div>
              <button className="flex items-center gap-3 px-8 py-4 bg-[#F8F9FA] text-[#2D5A27] font-black text-sm rounded-2xl hover:bg-gray-100 transition-colors shadow-sm">
                <Edit2 className="w-5 h-5" /> Edit Profile
              </button>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <h2 className="text-3xl font-black text-gray-900 tracking-tight">{user.name}</h2>
                <span className="text-[10px] font-black bg-[#E9C46A] text-[#2D5A27] px-2 py-1 rounded-lg uppercase tracking-wider">{user.employeeId}</span>
              </div>
              <div className="flex items-center gap-2 text-[#2D5A27] font-bold">
                <Shield className="w-4 h-4" />
                <span className="text-sm uppercase tracking-widest">{user.role}</span>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-4">
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 group hover:bg-white hover:shadow-md transition-all">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:bg-[#2D5A27]/5">
                  <Shield className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Employee ID Number</p>
                  <p className="text-sm font-bold text-gray-900">{user.employeeId}</p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 group hover:bg-white hover:shadow-md transition-all">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:bg-[#2D5A27]/5">
                  <Mail className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Official Email</p>
                  <p className="text-sm font-bold text-gray-900">{user.email}</p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 group hover:bg-white hover:shadow-md transition-all">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:bg-[#2D5A27]/5">
                  <Phone className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Contact Number</p>
                  <p className="text-sm font-bold text-gray-900">{user.phone}</p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 group hover:bg-white hover:shadow-md transition-all">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:bg-[#2D5A27]/5">
                  <Calendar className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Birth Date</p>
                  <p className="text-sm font-bold text-gray-900">{user.birthday}</p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4 group hover:bg-white hover:shadow-md transition-all">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm group-hover:bg-[#2D5A27]/5">
                  <MapPin className="w-5 h-5 text-[#2D5A27]" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Office Assignment</p>
                  <p className="text-sm font-bold text-gray-900">Regional Office - IV-A</p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100 flex justify-between items-center">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white"></div>
                ))}
              </div>
              <p className="text-xs font-bold text-gray-500">Managing 24 active documents</p>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
