import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Bell, User, ChevronDown, LogOut, ShieldCheck } from 'lucide-react';
import { ProfileModal } from './ProfileModal';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Standard utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface HeaderProps {
  userImage: string;
  currentUser: {
    name: string;
    role: string;
    email: string;
    phone: string;
    birthday: string;
    employeeId: string;
  };
  onLogout: () => void;
}

export function Header({ userImage, currentUser, onLogout }: HeaderProps) {
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  
  // Refs for closing dropdowns when clicking outside
  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-20 bg-white/80 backdrop-blur-md border-b border-gray-100 flex items-center justify-between px-8 sticky top-0 z-[100]">
      
      {/* Search Bar Section */}
      <div className="relative w-full max-w-md group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#2D5A27] transition-colors w-4 h-4" />
        <input
          type="text"
          placeholder="Search Tracking ID or Document Title..."
          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-transparent rounded-2xl focus:bg-white focus:border-[#2D5A27]/20 focus:ring-4 focus:ring-[#2D5A27]/5 outline-none transition-all text-sm font-medium"
        />
      </div>

      <div className="flex items-center gap-6">
        {/* Status Badge */}
        <div className="hidden lg:flex items-center gap-2.5 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100/50">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span className="text-[10px] font-black uppercase tracking-wider">Gateway Secure</span>
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
        </div>

        {/* Notifications */}
        <div className="relative" ref={notifRef}>
          <button 
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            className={cn(
              "relative p-2.5 rounded-xl transition-all",
              isNotificationsOpen ? "bg-[#2D5A27] text-white shadow-lg shadow-green-900/20" : "text-gray-400 hover:bg-gray-100"
            )}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full"></span>
          </button>
          
          <AnimatePresence>
            {isNotificationsOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-3 w-80 bg-white rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-gray-100 p-5 z-[101]"
              >
                <div className="flex items-center justify-between mb-4 px-1">
                  <h3 className="font-black text-slate-900 text-xs uppercase tracking-widest">Urgent Alerts</h3>
                  <span className="px-2 py-0.5 bg-red-50 text-red-600 rounded-md text-[9px] font-black">2 NEW</span>
                </div>
                <div className="space-y-3">
                  {[1, 2].map((i) => (
                    <div key={i} className="flex gap-4 p-3 hover:bg-slate-50 rounded-2xl transition-colors cursor-pointer border border-transparent hover:border-slate-100">
                      <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center shrink-0 border border-red-100">
                        <Bell className="w-4 h-4 text-red-500" />
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-xs font-black text-gray-800 uppercase tracking-tight">Delayed: Budget Request</p>
                        <p className="text-[10px] text-gray-500 font-medium leading-tight">Finance Dept. has not responded for 48h.</p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Profile Dropdown */}
        <div className="relative" ref={profileRef}>
          <div 
            className="flex items-center gap-4 pl-6 border-l border-gray-100 cursor-pointer group"
            onClick={() => setIsProfileOpen(!isProfileOpen)}
          >
            <div className="text-right hidden sm:block">
              <p className="text-xs font-black text-slate-900 leading-none group-hover:text-[#2D5A27] transition-colors uppercase tracking-tight">{currentUser.name}</p>
              <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase tracking-widest">{currentUser.role}</p>
            </div>
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl overflow-hidden border-2 border-[#E9C46A] shadow-lg group-hover:scale-105 transition-all">
                <img src={userImage} alt="Profile" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-1 -right-1 bg-green-500 w-3.5 h-3.5 border-2 border-white rounded-full shadow-sm" />
            </div>
            <ChevronDown className={cn("w-4 h-4 text-gray-300 transition-transform duration-300", isProfileOpen && "rotate-180 text-[#2D5A27]")} />
          </div>

          <AnimatePresence>
            {isProfileOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-3 w-64 bg-white rounded-[1.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-gray-100 py-3 z-[101] overflow-hidden"
              >
                <div className="px-5 py-2 mb-2">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em]">Management Access</p>
                </div>
                
                <button 
                  onClick={() => {
                    setIsProfileModalOpen(true);
                    setIsProfileOpen(false);
                  }}
                  className="w-full text-left px-5 py-3.5 text-xs font-black text-slate-600 hover:bg-[#2D5A27]/5 hover:text-[#2D5A27] flex items-center gap-3 transition-all group/item"
                >
                  <div className="p-1.5 bg-slate-50 rounded-lg group-hover/item:bg-white transition-colors">
                    <User className="w-4 h-4" />
                  </div>
                  VIEW FULL PROFILE
                </button>
                
                <div className="px-4 my-2">
                  <div className="h-px bg-slate-50 w-full" />
                </div>
                
                <button 
                  onClick={onLogout}
                  className="w-full text-left px-5 py-3.5 text-xs font-black text-red-600 hover:bg-red-50 flex items-center gap-3 transition-all"
                >
                  <div className="p-1.5 bg-red-100/50 rounded-lg">
                    <LogOut className="w-4 h-4" />
                  </div>
                  SYSTEM LOGOUT
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <ProfileModal 
        isOpen={isProfileModalOpen} 
        onClose={() => setIsProfileModalOpen(false)} 
        user={currentUser}
        userImage={userImage}
      />
    </header>
  );
}