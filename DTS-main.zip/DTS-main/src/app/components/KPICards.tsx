import React from "react";

export function KPICards({ documents = [], onFilter, activeFilter }: any) {
  const now = new Date();
  const stats = {
    total: documents.length,
    pending: documents.filter((d: any) => d.current_status === 'Pending').length,
    completed: documents.filter((d: any) => d.current_status === 'Approved' || d.current_status === 'Completed').length,
    // Bubukas lang ito kung TALAGANG delayed na (Urgent + Past Due)
    delayed: documents.filter((d: any) => d.priority === 'Urgent' && d.due_date && new Date(d.due_date) < now).length
  };

  const cardStyle = (filter: string) => `
    p-8 bg-white rounded-[2.5rem] border transition-all cursor-pointer 
    ${activeFilter === filter ? "border-[#2D5A27] ring-4 ring-green-50" : "border-slate-100 hover:border-slate-200"}
  `;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div onClick={() => onFilter("All")} className={cardStyle("All")}>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total Documents</p>
        <h3 className="text-4xl font-black text-slate-800">{stats.total} <span className="text-[10px] text-slate-300">DOCS</span></h3>
      </div>
      <div onClick={() => onFilter("Pending")} className={cardStyle("Pending")}>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Pending Approvals</p>
        <h3 className="text-4xl font-black text-amber-500">{stats.pending} <span className="text-[10px] text-amber-200 uppercase">In Queue</span></h3>
      </div>
      <div onClick={() => onFilter("Approved")} className={cardStyle("Approved")}>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Completed Actions</p>
        <h3 className="text-4xl font-black text-[#2D5A27]">{stats.completed} <span className="text-[10px] text-green-200 uppercase">Resolved</span></h3>
      </div>
      <div onClick={() => onFilter("Urgent")} className={cardStyle("Urgent")}>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Delayed / Urgent</p>
        <h3 className="text-4xl font-black text-red-500">{stats.delayed} <span className="text-[10px] text-red-200 uppercase">Action Needed</span></h3>
      </div>
    </div>
  );
}