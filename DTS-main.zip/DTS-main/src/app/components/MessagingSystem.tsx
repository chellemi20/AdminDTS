import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion'; // Standard import to avoid errors
import { toast } from 'sonner';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { apiFetch, apiJson } from '../lib/api';
import { 
  Search, 
  MessageSquare, 
  Plus, 
  Send,
  User,
  MoreVertical,
  ChevronRight,
  Phone,
  Video,
  FileText,
  X,
  Check
} from 'lucide-react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Role = 'DIRECTOR' | 'ADMIN HEAD' | 'ADMIN STAFF' | 'ADMIN ASSISTANT';

interface Contact {
  id: string;
  name: string;
  role: Role;
  title: string;
  office: string;
  avatar?: string;
  lastMessage?: string;
  time?: string;
  status: 'online' | 'offline';
  unread?: number;
}

interface Message {
  id: string;
  senderId: string;
  text: string;
  time: string;
  isMe: boolean;
}

const mockContacts: Contact[] = [
  {
    id: '1',
    name: 'Juan Dela Cruz',
    role: 'DIRECTOR',
    title: 'Director IV - Administrative Service',
    office: 'OSEC',
    status: 'online',
    lastMessage: 'The memo has been signed and forwarded.',
    time: '2 mins ago',
    unread: 2
  },
  {
    id: '2',
    name: 'Maria Clara',
    role: 'ADMIN HEAD',
    title: 'Head of Crops Department',
    office: 'Regional Office III',
    status: 'online',
    lastMessage: 'Kindly check the distribution report.',
    time: '1 hour ago'
  },
  {
    id: '3',
    name: 'Jose Rizal',
    role: 'ADMIN STAFF',
    title: 'Senior Administrative Officer',
    office: 'Livestock Bureau',
    status: 'offline',
    lastMessage: 'Noted on the deadline changes.',
    time: 'Yesterday'
  },
  {
    id: '4',
    name: 'Elena Guerrero',
    role: 'ADMIN ASSISTANT',
    title: 'Administrative Assistant II',
    office: 'Fisheries Division',
    status: 'online',
    lastMessage: 'Uploaded the verification files.',
    time: 'Yesterday'
  }
];

const mockMessages: Record<string, Message[]> = {
  '1': [
    { id: '1', senderId: 'me', text: 'Good morning, Director. Here is the update on the Seed Distribution Proposal.', time: '10:00 AM', isMe: true },
    { id: '2', senderId: '1', text: 'Thank you. I have reviewed the initial draft.', time: '10:15 AM', isMe: false },
    { id: '3', senderId: '1', text: 'The memo has been signed and forwarded to the Regional Office.', time: '10:30 AM', isMe: false },
  ]
};

export function MessagingSystem({ currentUser }: { currentUser: any }) {
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [isNewMessageModalOpen, setIsNewMessageModalOpen] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [messages, setMessages] = useState<Record<string, Message[]>>({});

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFile({
        name: file.name,
        size: (file.size / 1024).toFixed(1) + ' KB'
      });
      toast.success('File attached', {
        description: `${file.name} ready to send.`,
      });
    }
  };

  const removeAttachment = () => {
    setAttachedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         contact.office.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter ? contact.role === roleFilter : true;
    return matchesSearch && matchesRole;
  });

  const selectedContact = contacts.find(c => c.id === selectedContactId);
  const currentMessages = selectedContactId ? (messages[selectedContactId] || []) : [];

  // Fetch contacts (real users) when component mounts
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await apiJson<any[]>('/api/users');
        if (cancelled) return;
        const mapped: Contact[] = data
          .filter((u: any) => String(u.user_id) !== String(currentUser?.user_id) && String(u.status || '').trim().toLowerCase() === 'approved')
          .map((u: any) => ({
            id: String(u.user_id),
            name: u.full_name,
            role: u.role || 'ADMIN STAFF',
            title: u.department || '',
            office: u.department || '',
            status: 'offline',
            lastMessage: '',
            time: '',
          }));
        setContacts(mapped);
      } catch (e) {
        console.error('Failed to load users', e);
      }
    })();
    return () => { cancelled = true; };
  }, [currentUser]);

  // Fetch conversation when selecting a contact
  useEffect(() => {
    if (!selectedContactId || !currentUser) return;
    let cancelled = false;
    (async () => {
      try {
        const data = await apiJson<any[]>(`/api/messages?userId=${encodeURIComponent(currentUser.user_id)}&withUser=${encodeURIComponent(selectedContactId)}`);
        if (cancelled) return;
        const mapped: Message[] = data.map((m: any) => ({ id: String(m.msg_id || m.id), senderId: String(m.sender_id), text: m.text || m.message_text, time: m.created_at, isMe: String(m.sender_id) === String(currentUser.user_id) }));
        setMessages(prev => ({ ...prev, [selectedContactId]: mapped }));
      } catch (e) {
        console.error('Failed to load messages', e);
      }
    })();
    return () => { cancelled = true; };
  }, [selectedContactId, currentUser]);

  const getRoleBadgeStyles = (role: Role) => {
    switch (role) {
      case 'DIRECTOR': return 'bg-[#E9C46A]/10 text-[#E9C46A] border-[#E9C46A]/20';
      case 'ADMIN HEAD': return 'bg-[#2D5A27]/10 text-[#2D5A27] border-[#2D5A27]/20';
      default: return 'bg-slate-100 text-slate-500 border-slate-200';
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-140px)] lg:h-[calc(100vh-180px)] bg-white rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-100 relative">
      
      {/* 1. CONTACT LIST */}
      <div className={cn(
        "w-full lg:w-[380px] border-r border-slate-100 flex flex-col bg-white shrink-0 transition-all",
        selectedContactId && "hidden lg:flex"
      )}>
        <div className="h-[90px] px-8 flex items-center justify-between border-b border-slate-50 shrink-0">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Messages</h2>
          <button 
            onClick={() => setIsNewMessageModalOpen(true)}
            className="p-3 bg-slate-50 text-slate-400 hover:text-[#2D5A27] hover:bg-green-50 rounded-2xl transition-all"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 shrink-0 border-b border-slate-50">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-[#2D5A27]" />
            <input 
              type="text" 
              placeholder="Search personnel..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-[11px] font-bold outline-none focus:ring-4 focus:ring-[#2D5A27]/5 focus:border-[#2D5A27] transition-all"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredContacts.map((contact) => (
            <button
              key={contact.id}
              onClick={() => setSelectedContactId(contact.id)}
              className={cn(
                "w-full p-6 flex items-start gap-4 text-left transition-all border-b border-slate-50",
                selectedContactId === contact.id ? 'bg-[#2D5A27]/[0.03]' : 'hover:bg-slate-50/50'
              )}
            >
              <div className="relative shrink-0">
                <div className={cn(
                  "w-12 h-12 rounded-2xl bg-slate-100 border-2 flex items-center justify-center overflow-hidden transition-all",
                  selectedContactId === contact.id ? 'border-[#2D5A27]' : 'border-transparent'
                )}>
                  <User className={cn("w-6 h-6", selectedContactId === contact.id ? 'text-[#2D5A27]' : 'text-slate-300')} />
                </div>
                {contact.status === 'online' && (
                  <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white shadow-sm" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h4 className={cn("text-sm font-black truncate", selectedContactId === contact.id ? 'text-[#2D5A27]' : 'text-slate-900')}>
                    {contact.name}
                  </h4>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{contact.time}</span>
                </div>
                <p className="text-[11px] text-slate-500 truncate font-medium">{contact.lastMessage}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. CHAT AREA */}
      <div className={cn(
        "flex-1 flex flex-col bg-[#F8F9FA]/40 relative",
        !selectedContactId && "hidden lg:flex"
      )}>
        {selectedContact ? (
          <>
            <div className="h-[90px] px-8 lg:px-12 flex items-center border-b border-slate-100 bg-white/80 backdrop-blur-md z-10">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-4">
                  <button onClick={() => setSelectedContactId(null)} className="lg:hidden p-2 text-slate-400">
                    <X className="w-5 h-5" />
                  </button>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-2xl bg-[#2D5A27] flex items-center justify-center text-white shadow-lg shadow-green-900/10">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm lg:text-base font-black text-slate-900 leading-none">{selectedContact.name}</h3>
                    <p className="text-[9px] lg:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1.5">{selectedContact.title}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-3 text-slate-400 hover:text-[#2D5A27] transition-all"><Phone className="w-4 h-4" /></button>
                  <button className="p-3 text-slate-400 hover:text-[#2D5A27] transition-all"><MoreVertical className="w-4 h-4" /></button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-8 lg:p-12 space-y-8">
              <div className="flex justify-center mb-4">
                <span className="px-4 py-1.5 bg-white border border-slate-100 rounded-full text-[9px] font-black text-slate-300 uppercase tracking-widest">Official Channel</span>
              </div>
              {currentMessages.map((msg) => (
                <motion.div 
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn("flex", msg.isMe ? 'justify-end' : 'justify-start')}
                >
                  <div className={cn("max-w-[85%] lg:max-w-[70%] flex flex-col gap-2", msg.isMe ? 'items-end' : 'items-start')}>
                    <div className={cn(
                      "px-6 py-4 rounded-[1.5rem] text-sm font-medium shadow-sm leading-relaxed",
                      msg.isMe ? 'bg-[#2D5A27] text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'
                    )}>
                      {msg.text}
                    </div>
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest px-1">{msg.time}</span>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="p-8 lg:p-10 bg-white border-t border-slate-100">
              <div className="max-w-4xl mx-auto">
                <AnimatePresence>
                  {attachedFile && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                      className="flex items-center gap-3 bg-green-50 border border-green-100 p-3 rounded-2xl w-fit mb-4"
                    >
                      <FileText className="w-4 h-4 text-[#2D5A27]" />
                      <span className="text-[10px] font-black text-[#2D5A27] uppercase">{attachedFile.name}</span>
                      <button onClick={removeAttachment} className="p-1 hover:bg-green-100 rounded-lg"><X className="w-3 h-3 text-[#2D5A27]" /></button>
                    </motion.div>
                  )}
                </AnimatePresence>
                <div className="flex items-center gap-4 bg-slate-50 p-2 rounded-[2rem] border border-slate-100">
                  <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                  <button onClick={() => fileInputRef.current?.click()} className="p-4 text-slate-400 hover:text-[#2D5A27] transition-colors"><Plus className="w-6 h-6" /></button>
                  <input 
                    type="text" 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type official response..." 
                    className="flex-1 bg-transparent border-none outline-none text-sm font-bold py-2"
                  />
                  <button 
                    onClick={async () => {
                      if ((!newMessage.trim() && !attachedFile) || !selectedContact) return;
                      try {
                        const payload = { sender_id: currentUser.user_id, receiver_id: selectedContact.id, text: newMessage.trim() };
                        const res = await apiFetch('/api/messages', { method: 'POST', body: JSON.stringify(payload) });
                        if (res.ok) {
                          // append locally
                          const newMsg: Message = { id: Date.now().toString(), senderId: String(currentUser.user_id), text: newMessage.trim(), time: new Date().toISOString(), isMe: true };
                          setMessages(prev => ({ ...prev, [selectedContact.id]: [...(prev[selectedContact.id] || []), newMsg] }));
                          toast.success('Message sent');
                          setNewMessage('');
                          removeAttachment();
                        } else {
                          toast.error('Failed to send message');
                        }
                      } catch (e) {
                        console.error(e);
                        toast.error('Failed to send message');
                      }
                    }}
                    className="p-4 bg-[#2D5A27] text-white rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center">
            <div className="w-24 h-24 bg-white rounded-full shadow-xl flex items-center justify-center mb-6">
              <MessageSquare className="w-10 h-10 text-[#2D5A27]" />
            </div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">Select a Thread</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2">Choose a colleague to begin official communication</p>
          </div>
        )}
      </div>
      
      {/* NEW MESSAGE MODAL */}
      <AnimatePresence>
        {isNewMessageModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-slate-50 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-900">New Message</h3>
                <button onClick={() => setIsNewMessageModalOpen(false)} className="p-2 text-slate-400 hover:rotate-90 transition-transform"><X className="w-6 h-6" /></button>
              </div>
              <div className="p-4 max-h-[400px] overflow-y-auto">
                {contacts.length === 0 ? (
                  <div className="p-6 text-center text-sm text-slate-500">No approved users available to message.</div>
                ) : (
                  contacts.map(c => (
                    <button key={c.id} onClick={() => { setSelectedContactId(c.id); setIsNewMessageModalOpen(false); }} className="w-full p-4 flex items-center gap-4 hover:bg-slate-50 rounded-2xl transition-all">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center"><User className="w-5 h-5 text-slate-400" /></div>
                      <div className="text-left">
                        <div className="text-xs font-black text-slate-900">{c.name}</div>
                        <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{c.role}</div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}