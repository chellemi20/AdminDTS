import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Area, 
  AreaChart 
} from 'recharts';
import { motion } from 'motion/react';
import { Clock, CheckCircle2, AlertCircle, TrendingUp, FileText } from 'lucide-react';

const weeklyFlowData = [
  { day: 'Mon', flow: 45, approvals: 30 },
  { day: 'Tue', flow: 62, approvals: 45 },
  { day: 'Wed', flow: 58, approvals: 40 },
  { day: 'Thu', flow: 75, approvals: 55 },
  { day: 'Fri', flow: 88, approvals: 70 },
  { day: 'Sat', flow: 30, approvals: 25 },
  { day: 'Sun', flow: 20, approvals: 15 },
];

export function DashboardVisuals() {
  return (
    <div className="space-y-10">
      {/* Large Status Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: 'Pending Approvals', value: '42', icon: Clock, color: 'text-amber-500', bg: 'bg-amber-50', trend: '+5 today' },
          { label: 'Approved Documents', value: '892', icon: CheckCircle2, color: 'text-[#2D5A27]', bg: 'bg-green-50', trend: '+24 this week' },
          { label: 'Delayed Actions', value: '12', icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50', trend: '-2 since yesterday' },
        ].map((stat, i) => (
          <motion.div 
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-10 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-50 relative overflow-hidden group hover:translate-y-[-8px] transition-all duration-500"
          >
            <div className="absolute top-0 right-0 -mr-8 -mt-8 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity duration-700">
               <stat.icon className="w-48 h-48 rotate-12" />
            </div>
            
            <div className="flex items-center gap-6 mb-8 relative z-10">
              <div className={`w-16 h-16 rounded-[1.5rem] ${stat.bg} ${stat.color} flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-500`}>
                <stat.icon className="w-8 h-8" />
              </div>
              <div className="px-4 py-1.5 rounded-full bg-slate-50 border border-slate-100 flex items-center gap-2">
                <TrendingUp className="w-3 h-3 text-green-500" />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.trend}</span>
              </div>
            </div>

            <div className="relative z-10">
              <h3 className="text-sm font-black text-slate-400 uppercase tracking-[0.25em] mb-2">{stat.label}</h3>
              <div className="text-6xl font-black text-slate-900 tracking-tighter leading-none">{stat.value}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Full-width Weekly Document Flow Chart */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-12 rounded-[3.5rem] shadow-2xl shadow-slate-200/50 border border-slate-50 flex flex-col min-h-[500px]"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-[#2D5A27] text-white rounded-xl shadow-lg shadow-green-900/20">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Weekly Document Flow</h2>
            </div>
            <div className="text-slate-400 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#2D5A27]"></div>
              Traffic volume comparison of incoming vs processed files
            </div>
          </div>
          
          <div className="flex items-center gap-8 bg-slate-50 px-8 py-5 rounded-3xl border border-slate-100">
             <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Flow</span>
                <span className="text-lg font-black text-slate-900">360 <span className="text-[10px] text-green-500 ml-1">↑ 14%</span></span>
             </div>
             <div className="w-px h-10 bg-slate-200" />
             <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Success Rate</span>
                <span className="text-lg font-black text-slate-900">92.4%</span>
             </div>
          </div>
        </div>

        <div className="flex-1 w-full min-h-[350px] relative">
          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={350}>
            <AreaChart data={weeklyFlowData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorFlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2D5A27" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#2D5A27" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 11, fontWeight: 900, fill: '#94a3b8' }}
                dy={20}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 11, fontWeight: 900, fill: '#94a3b8' }}
              />
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '24px', 
                  border: 'none', 
                  boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)',
                  padding: '24px'
                }}
                itemStyle={{ fontSize: '13px', fontWeight: 900 }}
              />
              <Area 
                type="monotone" 
                dataKey="flow" 
                stroke="#2D5A27" 
                strokeWidth={5} 
                fillOpacity={1} 
                fill="url(#colorFlow)" 
                dot={{ r: 6, fill: '#2D5A27', strokeWidth: 3, stroke: '#fff' }}
                activeDot={{ r: 10, strokeWidth: 0, fill: '#E9C46A' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
