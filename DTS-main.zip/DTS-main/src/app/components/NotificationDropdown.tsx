import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Bell, CheckCircle2, FileText, Printer, Clock, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion'; // Inayos ang import source
import { toast } from 'sonner';
import { apiJson } from '../lib/api';

interface AppNotification {
  id: string;
  title: string;
  description: string;
  time: string; // ISO timestamp from server
  isRead?: boolean;
  type: 'document_upload' | 'document_status' | 'user_registration' | 'user_status';
}

// Component state will fetch real notifications from backend

export const NotificationDropdown = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const hasLoadedNotificationsRef = useRef(false);
  const seenNotificationIdsRef = useRef<Set<string>>(new Set());

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchNotifications = useCallback(async (showToast = false) => {
    try {
      const data = await apiJson<any[]>('/api/notifications');
      const mapped = data.map((n: any) => ({
        id: String(n.id),
        title: n.title,
        description: n.description,
        time: n.time || n.created_at,
        isRead: n.isRead === undefined ? !!n.is_read : !!n.isRead,
        type: n.type
      })) as AppNotification[];

      const seenIds = seenNotificationIdsRef.current;
      const freshUnread = mapped.filter((notif) => !notif.isRead && !seenIds.has(notif.id));
      if (showToast && hasLoadedNotificationsRef.current && freshUnread.length > 0) {
        freshUnread.slice(0, 3).reverse().forEach((notif) => {
          toast(notif.title, {
            id: `notification-${notif.id}`,
            description: notif.description || undefined,
            duration: 5000,
          });
        });
      }

      seenNotificationIdsRef.current = new Set([
        ...Array.from(seenIds),
        ...mapped.map((notif) => notif.id),
      ]);
      hasLoadedNotificationsRef.current = true;
      setNotifications(mapped);
    } catch (err) {
      console.error('Failed to fetch notifications', err);
    }
  }, []);

  useEffect(() => {
    fetchNotifications(false);
    const intervalId = window.setInterval(() => fetchNotifications(true), 10000);
    return () => window.clearInterval(intervalId);
  }, [fetchNotifications]);

  useEffect(() => {
    if (isOpen) fetchNotifications(false);
  }, [isOpen, fetchNotifications]);

  // Simple relative time formatter
  function timeAgo(iso: string) {
    try {
      const diff = Date.now() - new Date(iso).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / 60);
      if (hours < 24) return `${hours}h ago`;
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    } catch (e) {
      return iso;
    }
  }

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2.5 text-slate-500 hover:text-[#2D5A27] hover:bg-green-50 rounded-xl transition-all duration-300 group"
      >
        <Bell className="w-5 h-5 group-hover:rotate-[15deg] transition-transform" />
        {notifications.some(n => !n.isRead) && (
          <span className="absolute top-2 right-2.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            className="absolute right-0 mt-4 w-[340px] bg-white rounded-[24px] shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-slate-100 overflow-hidden z-[100]"
          >
            {/* Header */}
            <div className="p-5 border-b border-slate-50 flex items-center justify-between bg-white">
              <div>
                <h3 className="font-black text-[#2D5A27] text-sm uppercase tracking-wider">Notifications</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5">You have {notifications.filter(n => !n.isRead).length} unread alerts</p>
              </div>
              <button
                onClick={async () => {
                  try {
                    await apiJson('/api/notifications/mark-all', { method: 'POST', body: JSON.stringify({}) });
                    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
                  } catch (e) { console.error(e); }
                }}
                className="text-[9px] font-black text-[#2D5A27] uppercase tracking-widest bg-green-50 px-3 py-1.5 rounded-lg hover:bg-[#2D5A27] hover:text-white transition-all"
              >
                Mark All
              </button>
            </div>

            {/* List */}
            <div className="max-h-[380px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-100">
              {notifications.length > 0 ? (
                notifications.map((notif) => (
                  <div 
                    key={notif.id}
                    onClick={async () => {
                      if (!notif.isRead) {
                        try {
                          await apiJson('/api/notifications/mark-read', { method: 'POST', body: JSON.stringify({ id: notif.id }) });
                          setNotifications(prev => prev.map(p => p.id === notif.id ? { ...p, isRead: true } : p));
                        } catch (e) { console.error(e); }
                      }
                    }}
                    className="p-5 border-b border-slate-50 hover:bg-slate-50/80 transition-all cursor-pointer relative group"
                  >
                    {!notif.isRead && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#2D5A27]"></div>
                    )}
                    
                    <div className="flex gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border",
                        notif.type === 'document_upload' ? 'bg-amber-50 border-amber-100 text-amber-500' :
                        notif.type === 'document_status' ? 'bg-green-50 border-green-100 text-[#2D5A27]' :
                        notif.type === 'user_registration' ? 'bg-blue-50 border-blue-100 text-blue-500' :
                        'bg-slate-50 border-slate-100 text-slate-400'
                      )}>
                        {notif.type === 'document_upload' && <FileText className="w-5 h-5" />}
                        {notif.type === 'document_status' && <CheckCircle2 className="w-5 h-5" />}
                        {notif.type === 'user_registration' && <Bell className="w-5 h-5" />}
                        {notif.type === 'user_status' && <CheckCircle2 className="w-5 h-5" />}
                      </div>

                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <p className="text-[12px] font-black text-slate-900 leading-tight">
                            {notif.title}
                          </p>
                          {!notif.isRead && (
                            <span className="w-2 h-2 bg-[#2D5A27] rounded-full"></span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 font-medium mb-2 leading-relaxed">
                          {notif.description}
                        </p>
                        <div className="flex items-center gap-1.5 text-[9px] font-bold text-slate-400 uppercase tracking-wide">
                          <Clock className="w-3 h-3" />
                          {timeAgo(notif.time)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-12 text-center">
                  <Bell className="w-8 h-8 text-slate-200 mx-auto mb-3" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">No notifications yet</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <button className="w-full py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-[#2D5A27] hover:bg-slate-50 transition-all border-t border-slate-50">
              View All Activity Log
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Helper function for cleaner classes
function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
