import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { 
  Calendar, 
  Sun, 
  Moon, 
  CloudSun, 
  ShieldCheck 
} from 'lucide-react';

interface GreetingHeaderProps {
  userName: string;
}

export function GreetingHeader({ userName }: GreetingHeaderProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getGreetingData = () => {
    const hour = time.getHours();
    if (hour < 12) return { text: "Good morning", icon: <Sun className="w-6 h-6 text-[#E9C46A]" /> };
    if (hour < 18) return { text: "Good afternoon", icon: <CloudSun className="w-6 h-6 text-[#E9C46A]" /> };
    return { text: "Good evening", icon: <Moon className="w-6 h-6 text-[#E9C46A]" /> };
  };

  const greeting = getGreetingData();

  return (
    <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#2D5A27] via-[#3a7332] to-[#1e3d1a] p-10 text-white shadow-2xl shadow-green-900/30 border border-white/5">
      
      {/* Background Decor */}
      <div className="absolute -top-20 -right-20 h-80 w-80 rounded-full bg-white/5 blur-[80px]" />
      
      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-10">
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 rounded-2xl backdrop-blur-xl border border-white/20">
              {greeting.icon}
            </div>
            <div className="flex flex-col">
              <motion.h2 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-5xl font-black tracking-tight leading-none"
              >
                {greeting.text}, <span className="text-[#E9C46A]">{userName.split(' ')[0]}!</span>
              </motion.h2>
              <div className="flex items-center gap-2 mt-2 text-white/60 font-bold uppercase tracking-[0.3em] text-[9px]">
                <ShieldCheck className="w-3 h-3 text-green-400" />
                Verified Administrator Session
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3 text-white/90 font-bold bg-black/10 w-fit px-4 py-2 rounded-full border border-white/5">
              <Calendar className="w-4 h-4 text-[#E9C46A]" />
              <span className="text-sm">{format(time, 'EEEE, MMMM dd, yyyy')}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-start lg:items-end gap-2">
          <div className="text-6xl font-black tracking-tighter text-[#E9C46A] font-mono">
            {format(time, 'hh:mm:ss')}
            <span className="text-2xl ml-2 opacity-80">{format(time, 'a')}</span>
          </div>
          <div className="text-white/50 font-black uppercase tracking-[0.25em] text-[10px]">
            Official System Time (GMT+8)
          </div>
        </div>
      </div>
    </div>
  );
}