import React from 'react';
import { CheckCircle2, Clock, MapPin } from 'lucide-react';

export function LiveTracking({ selectedDoc }: any) {
  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm h-full min-h-[400px]">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Live Document Path</h3>
        {selectedDoc && (
          <span className="text-[10px] font-mono font-black text-[#2D5A27] bg-green-50 px-3 py-1 rounded-lg italic">
            {selectedDoc.tracking_number}
          </span>
        )}
      </div>

      {selectedDoc ? (
        <div className="space-y-10 relative">
          {/* Vertical Line */}
          <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-slate-100 z-0" />
          
          <div className="relative flex gap-6 z-10">
            <div className="w-6 h-6 rounded-full bg-[#2D5A27] flex items-center justify-center border-4 border-white shadow-sm">
              <CheckCircle2 className="w-3 h-3 text-white" />
            </div>
            <div>
              <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">Origin</p>
              <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">Document Created</p>
            </div>
          </div>

          <div className="relative flex gap-6 z-10">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center border-4 border-white shadow-sm ${selectedDoc.current_status === 'Pending' ? 'bg-amber-400' : 'bg-[#2D5A27]'}`}>
              {selectedDoc.current_status === 'Pending' ? <Clock className="w-3 h-3 text-white" /> : <CheckCircle2 className="w-3 h-3 text-white" />}
            </div>
            <div>
              <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">Office ID: {selectedDoc.destination_office_id}</p>
              <p className="text-[9px] text-amber-500 font-black uppercase tracking-tighter">{selectedDoc.current_status}</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="h-full flex flex-col items-center justify-center text-center opacity-30 mt-20">
          <MapPin className="w-10 h-10 text-slate-300 mb-4" />
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Select document to track</p>
        </div>
      )}
    </div>
  );
}