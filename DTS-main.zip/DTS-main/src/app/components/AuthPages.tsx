import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion'; 
import { Mail, Lock, User, ShieldCheck, ArrowRight, ChevronDown } from 'lucide-react';
import { BRAND_LOGO_URL } from '../lib/brand';
import { apiJson, setAuthSession } from '../lib/api';

interface AuthPagesProps {
  onLogin: (user: any) => void;
}

type AuthState = 'login' | 'register' | 'reset';

export function AuthPages({ onLogin }: AuthPagesProps) {
  const [authState, setAuthState] = useState<AuthState>('login');
  const [isPending, setIsPending] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // 1. INPUT STATES
  const [formData, setFormData] = useState({
    fullName: '',
    employeeId: '',
    role: 'STAFF', // Default updated to All Caps STAFF
    destinationOfficeId: '',
    email: '',
    password: ''
  });
  const [offices, setOffices] = useState<any[]>([]);

  useEffect(() => {
    const fetchOffices = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/public/offices');
        const data = await response.json();
        if (response.ok && Array.isArray(data)) {
          setOffices(data);
          if (data.length > 0) {
            setFormData((prev) => ({
              ...prev,
              destinationOfficeId: prev.destinationOfficeId || String(data[0].destination_office_id),
            }));
          }
        }
      } catch (err) {
        console.error('Unable to load offices:', err);
      }
    };

    if (authState === 'register') fetchOffices();
  }, [authState]);

  // 2. HANDLE INPUT CHANGES
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // 3. AUTHENTICATION LOGIC
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (authState === 'login') {
      try {
        const data = await apiJson<{ token: string; user: any }>('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            username: formData.email,
            password: formData.password,
          }),
        });
        setAuthSession(data.token, data.user);
        onLogin(data.user);
      } catch (err) {
        setErrorMessage((err as Error)?.message || 'Login failed.');
      }
    } else if (authState === 'register') {
      try {
        // I-format ang data para tugma sa Database Columns mo sa phpMyAdmin
      // Hanapin ang registerData sa AuthPages.tsx at palitan ng ganito:
const registerData = {
  full_name: formData.fullName,      // Siguraduhing may underscore (_)
  employee_id: formData.employeeId,  // Siguraduhing may underscore (_)
  role: formData.role,
  email_address: formData.email,
  password: formData.password,
  username: formData.email, 
  destination_office_id: Number(formData.destinationOfficeId),
  department: offices.find((office) => String(office.destination_office_id) === formData.destinationOfficeId)?.office_name || "General Services",
  status: "Pending" 
};
        const response = await fetch('http://localhost:5000/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(registerData),
        });
        
        if (response.ok) {
          setIsPending(true); 
        } else {
          const data = await response.json();
          setErrorMessage(data.error || 'Registration failed.');
        }
      } catch (err) {
        setErrorMessage('Server error. Please check your backend terminal.');
      }
    }
  };

  if (isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[#F8F9FA]">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-12 rounded-[3rem] shadow-xl max-w-lg w-full text-center border border-gray-100"
        >
          <div className="w-24 h-24 bg-[#D4AF37] rounded-full flex items-center justify-center mx-auto mb-8 shadow-xl">
            <ShieldCheck className="w-12 h-12 text-[#2D5A27]" />
          </div>
          <h2 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">Registration Sent</h2>
          <p className="text-gray-500 font-bold leading-relaxed mb-8 text-sm">
            Your employee profile has been submitted. Please wait for the <span className="text-[#2D5A27]">Admin Head</span> to approve your access.
          </p>
          <button 
            onClick={() => { setIsPending(false); setAuthState('login'); }}
            className="w-full py-4 bg-[#2D5A27] text-white font-black rounded-2xl hover:bg-[#23471f] transition-all uppercase tracking-widest text-xs"
          >
            Back to Sign In
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#F8F9FA]">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-[1200px] bg-white rounded-[12px] shadow-2xl overflow-hidden flex min-h-[750px] border border-gray-100"
      >
        {/* Left Side: Branding */}
        <div className="hidden lg:flex lg:w-5/12 bg-[#2D5A27] p-20 flex-col justify-between text-white relative">
          <div className="relative z-10">
            <div className="bg-white p-4 rounded-[12px] inline-block mb-10 shadow-xl">
              <img src={BRAND_LOGO_URL} alt="DA Logo" className="w-20 h-20 object-contain" />
            </div>
            <h1 className="text-5xl font-black mb-6 leading-tight tracking-tight text-[#D4AF37]">
              Administrator <br/>
              <span className="text-white text-4xl">Document Tracking System (DA)</span>
            </h1>
            <p className="text-white/70 text-xl font-medium max-w-sm">
              Securing official records and accelerating departmental coordination.
            </p>
          </div>
          <div className="relative z-10">
             <div className="bg-black/20 p-8 rounded-[12px] backdrop-blur-xl border border-white/10 shadow-2xl">
                <p className="text-sm text-white/80 leading-relaxed italic">
                  "Digitizing the backbone of our nation through accountable record management."
                </p>
             </div>
          </div>
        </div>

        {/* Right Side: Forms */}
        <div className="w-full lg:w-7/12 p-12 lg:p-16 flex flex-col justify-center bg-white overflow-y-auto">
          <div className="max-w-md mx-auto w-full">
            <div className="mb-8">
              <h2 className="text-3xl font-black text-gray-900 mb-2">
                {authState === 'login' ? 'Welcome Back' : 'Create Official Account'}
              </h2>
              {errorMessage && (
                <div className="p-3 bg-red-50 text-red-600 text-xs font-bold rounded-lg border border-red-100 mb-4">
                  {errorMessage}
                </div>
              )}
            </div>

            <form className="space-y-4" onSubmit={handleAuth}>
              {authState === 'register' && (
                <>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Full Legal Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input name="fullName" value={formData.fullName} onChange={handleChange} type="text" placeholder="Full Name" className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Employee ID</label>
                      <input name="employeeId" value={formData.employeeId} onChange={handleChange} type="text" placeholder="DA-2026-XXXX" className="w-full px-4 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Role</label>
                      <div className="relative">
                        <select name="role" value={formData.role} onChange={handleChange} className="w-full pl-4 pr-10 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none appearance-none cursor-pointer text-sm font-medium">
                          {/* Mahalaga: All Caps ang values dito para tugma sa Sidebar at DB */}
                          <option value="STAFF">Admin Staff</option>
                          <option value="RecordsStaff">Records Staff</option>
                          <option value="Director">Director</option>
                          <option value="AdminHead">Admin Head</option>
                          <option value="SuperAdmin">Super Admin</option>
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Office</label>
                      <div className="relative">
                        <select
                          name="destinationOfficeId"
                          value={formData.destinationOfficeId}
                          onChange={handleChange}
                          className="w-full pl-4 pr-10 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none appearance-none cursor-pointer text-sm font-medium"
                          required
                        >
                          {offices.length === 0 ? (
                            <option value="">Loading offices...</option>
                          ) : (
                            offices.map((office) => (
                              <option key={office.destination_office_id} value={office.destination_office_id}>
                                {office.office_name}
                              </option>
                            ))
                          )}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                      </div>
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Username / Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input name="email" value={formData.email} onChange={handleChange} type="text" placeholder="rochelle@2026" className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none transition-all font-medium" required />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input name="password" value={formData.password} onChange={handleChange} type="password" placeholder="••••••••" className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-[12px] focus:border-[#2D5A27] outline-none transition-all font-medium" required />
                </div>
              </div>

              <button type="submit" className="w-full py-4 bg-[#2D5A27] text-white font-black rounded-[12px] shadow-lg hover:bg-[#23471f] transition-all flex items-center justify-center gap-2 group mt-6 uppercase tracking-widest text-xs">
                {authState === 'login' ? 'Authorize Access' : 'Submit Registration'}
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>

            <div className="mt-8 pt-8 border-t border-gray-50 flex flex-col items-center">
              <button 
                onClick={() => { setAuthState(authState === 'login' ? 'register' : 'login'); setErrorMessage(''); }}
                className="text-gray-500 text-sm font-bold hover:text-[#2D5A27] transition-colors"
              >
                {authState === 'login' ? "New personnel? Register Here" : "Existing employee? Sign In Instead"}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
