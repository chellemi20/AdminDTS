import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Dashboard Components
import DocumentWorkflow from "./components/DocumentWorkflow";
import { SettingsPage } from "./components/SettingsPage";
import { Sidebar } from "./components/Sidebar";
import { KPICards } from "./components/KPICards";
import { CreateDocumentModal } from "./components/CreateDocumentModal";
import { NotificationDropdown } from "./components/NotificationDropdown";
import { MessagingSystem } from "./components/MessagingSystem";
import { AnalyticalReports } from "./components/AnalyticalReports";
import { ApprovalPage } from "./components/ApprovalsTab";
import { LiveTracking } from "./components/LiveTracking";
import { DashboardPanels } from "./components/DashboardPanels";
import { GreetingHeader } from "./components/GreetingHeader";
import { AuthPages } from './components/AuthPages';
import { ActivityLogs } from "./components/ActivityLogs";

// UI & Icons
import { Plus, LayoutDashboard, Settings as SettingsIcon, User } from "lucide-react";
import { Toaster as HotToaster } from 'react-hot-toast';
import { Toaster as SonnerToaster } from 'sonner';
import { motion, AnimatePresence } from "framer-motion";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { apiJson, clearAuthSession, getAuthToken } from "./lib/api";

// Utility for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- 1. MAIN APP (ROUTING LOGIC) ---
export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isBootstrapping, setIsBootstrapping] = useState(true);

  const handleLogin = (userData: any) => {
    setIsAuthenticated(true);
    setCurrentUser(userData);
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('user', JSON.stringify(userData));
  };

  // Apply persisted theme on app load and listen for changes
  useEffect(() => {
    const applyTheme = (t: string) => {
      const root = document.documentElement;
      if (t === 'dark') root.classList.add('dark');
      else if (t === 'light') root.classList.remove('dark');
      else {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDark) root.classList.add('dark'); else root.classList.remove('dark');
      }
    };
    // Only apply dark theme automatically if the saved value is 'dark'
    // and the user is not on the login page. The login page should
    // remain light even when dark is selected.
    const pathname = window.location.pathname || '/';
    const saved = localStorage.getItem('dts_theme') || 'light';
    if (saved === 'dark' && pathname !== '/login') applyTheme('dark');

    const handler = (e: any) => {
      const newTheme = e?.detail || localStorage.getItem('dts_theme') || 'light';
      // don't change the login page appearance
      if (window.location.pathname === '/login') return;
      applyTheme(newTheme);
    };
    window.addEventListener('dts-theme-changed', handler as EventListener);

    return () => window.removeEventListener('dts-theme-changed', handler as EventListener);
  }, []);

  // Developer helper: force logout when visiting with ?forceLogout=1 or ?logout=1
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('forceLogout') === '1' || params.get('logout') === '1') {
        clearAuthSession();
        setIsAuthenticated(false);
        setCurrentUser(null);
        if (window.location.pathname !== '/login') window.location.href = '/login';
      }
    } catch (e) {
      // ignore
    }
  }, []);

  // Listen for explicit user updates from child components (no automatic restore)
  useEffect(() => {
    const handler = (e: any) => {
      if (e?.detail) setCurrentUser(e.detail);
    };
    window.addEventListener('dts-user-updated', handler as EventListener);
    return () => window.removeEventListener('dts-user-updated', handler as EventListener);
  }, []);

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    clearAuthSession();
  };

  useEffect(() => {
    const token = getAuthToken();
    if (!token) {
      setIsBootstrapping(false);
      return;
    }
    apiJson<{ user: any }>('/api/auth/me')
      .then((data) => {
        setCurrentUser(data.user);
        setIsAuthenticated(true);
      })
      .catch(() => {
        clearAuthSession();
        setCurrentUser(null);
        setIsAuthenticated(false);
      })
      .finally(() => setIsBootstrapping(false));
  }, []);

  return (
    <Router>
      <HotToaster position="top-right" />
      <SonnerToaster richColors position="top-right" />
      {isBootstrapping ? null : (
      <Routes>
        <Route 
          path="/login" 
          element={!isAuthenticated ? <AuthPages onLogin={handleLogin} /> : <Navigate to="/dashboard" replace />} 
        />
        <Route 
          path="/dashboard/*" 
          element={isAuthenticated ? <DashboardLayout currentUser={currentUser} onLogout={handleLogout} /> : <Navigate to="/login" replace />} 
        />
        <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
      </Routes>
      )}
    </Router>
  );
}

// --- 2. DASHBOARD LAYOUT COMPONENT ---
function DashboardLayout({ currentUser, onLogout }: { currentUser: any, onLogout: () => void }) {
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [isLiveTrackingOpen, setIsLiveTrackingOpen] = useState(false);
  const [documents, setDocuments] = useState<any[]>([]);
  const normalizedRole = String(currentUser?.role || '').toLowerCase().replace(/\s+/g, '');
  const isSuperAdmin = normalizedRole === 'superadmin';

  const fetchDocuments = async () => {
    if (isSuperAdmin) return;
    try {
      const data = await apiJson<any[]>('/api/documents');
      setDocuments(data);
    } catch (error) {
      console.error("Connection error:", error);
    }
  };

  useEffect(() => {
    if (!isSuperAdmin) fetchDocuments();
  }, [activeTab, isSuperAdmin]);

  useEffect(() => {
    if (isSuperAdmin && activeTab !== "Activity Logs" && activeTab !== "Settings") {
      setActiveTab("Activity Logs");
    }
  }, [activeTab, isSuperAdmin]);

  const filteredDocs = documents.filter((doc: any) => {
    const status = doc.current_status || doc.status;
    if (!filterStatus || filterStatus === "All") return true;
    if (filterStatus === "Pending") return status === "Pending";
    if (filterStatus === "Approved") return status === "Approved" || status === "Completed";
    if (filterStatus === "Urgent") return doc.priority === "Urgent";
    return true;
  });

  return (
    <div className="flex min-h-screen bg-[#F8F9FA] text-slate-900 font-['Inter'] overflow-x-hidden">
        <div className="hidden lg:block">
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onNewDocument={() => setIsUploadModalOpen(true)}
          currentUser={currentUser}
        />
      </div>

      <div className="flex-1 flex flex-col relative min-w-0 h-screen overflow-hidden">
        <header className="hidden lg:flex sticky top-0 z-[45] bg-white/80 backdrop-blur-md border-b border-slate-100 px-10 py-5 items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-[10px] font-black text-[#2D5A27] uppercase tracking-[0.2em] bg-green-50 px-4 py-2 rounded-full border border-green-100">
              Admin Portal Document Tracking System
            </div>
          </div>

          <div className="flex items-center gap-5">
            <NotificationDropdown />
            <div className="h-8 w-px bg-slate-100"></div>
            <div onClick={() => setActiveTab("Settings")} className="flex items-center gap-3 pl-2 group cursor-pointer hover:opacity-80 transition-opacity">
              <div className="text-right">
                <p className="text-sm font-black text-slate-800 leading-none mb-1 uppercase">
                  {currentUser?.full_name || "Administrator"}
                </p>
                <p className="text-[10px] font-bold text-[#2D5A27] uppercase tracking-wider">
                  {currentUser?.role || "Director"}
                </p>
              </div>
              
              {/* Profile Image Container with Fallback */}
              <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-[#fbcfe8] shadow-sm group-hover:scale-105 transition-transform flex items-center justify-center bg-[#fdf2f8]">
                {currentUser?.profile_image ? (
                  <img src={currentUser.profile_image} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-[#db2777] font-bold text-lg uppercase">
                    {currentUser?.full_name?.charAt(0) || <User className="w-5 h-5 text-[#db2777]" />}
                  </span>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6 lg:p-12 pb-32 lg:pb-12 bg-[#F8F9FA]">
          {activeTab === "Dashboard" && !isSuperAdmin && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-[1600px] mx-auto w-full space-y-8">
              <GreetingHeader userName={currentUser?.full_name?.split(" ").shift() || "Admin"} />
              <KPICards 
                documents={documents} 
                onFilter={(status: string) => setFilterStatus(status)} 
                activeFilter={filterStatus} 
              />
              <DashboardPanels 
                documents={filteredDocs} 
                onViewDoc={(doc: any) => { setSelectedDoc(doc); setIsLiveTrackingOpen(true); }} 
              />
            </motion.div> 
          )}

          {activeTab === "Workflows" && !isSuperAdmin && <DocumentWorkflow currentUser={currentUser} />}
          {activeTab === "Approval Account" && !isSuperAdmin && <ApprovalPage />}
          {activeTab === "Reports" && !isSuperAdmin && <AnalyticalReports documents={documents} />}
          {activeTab === "Messages" && !isSuperAdmin && <MessagingSystem currentUser={currentUser} />}
          {activeTab === "Activity Logs" && isSuperAdmin && <ActivityLogs />}
          {activeTab === 'Settings' && <SettingsPage currentUser={currentUser} />}
        </main>

        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-4 flex items-center justify-between z-[55] pb-8 shadow-2xl">
          <button onClick={() => setActiveTab(isSuperAdmin ? "Activity Logs" : "Dashboard")} className={cn("flex flex-col items-center gap-1.5", (isSuperAdmin ? activeTab === "Activity Logs" : activeTab === "Dashboard") ? "text-[#2D5A27]" : "text-slate-300")}>
            <LayoutDashboard className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-tighter">{isSuperAdmin ? "Logs" : "Home"}</span>
          </button>
          {!isSuperAdmin && (
          <div className="relative -top-6">
            <button onClick={() => setIsUploadModalOpen(true)} className="w-16 h-16 bg-[#E9C46A] text-[#2D5A27] rounded-full shadow-xl flex items-center justify-center border-4 border-white active:scale-90 transition-transform">
              <Plus className="w-8 h-8 stroke-[3px]" />
            </button>
          </div>
          )}
          <button onClick={() => setActiveTab("Settings")} className={cn("flex flex-col items-center gap-1.5", activeTab === "Settings" ? "text-[#2D5A27]" : "text-slate-300")}>
            <SettingsIcon className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase tracking-tighter">Settings</span>
          </button>
        </nav>
      </div>

      <CreateDocumentModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)} 
        onSubmit={fetchDocuments} 
        currentUser={currentUser} 
      />

      <AnimatePresence>
        {isLiveTrackingOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsLiveTrackingOpen(false)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden p-8">
              <button onClick={() => setIsLiveTrackingOpen(false)} className="absolute top-6 right-6 p-2 hover:bg-slate-100 rounded-full transition-colors">
                <Plus className="w-6 h-6 rotate-45 text-slate-400" />
              </button>
              <LiveTracking selectedDoc={selectedDoc} />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
