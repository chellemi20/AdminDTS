export const BRAND_LOGO_URL =
  'https://th.bing.com/th/id/OIP.n588XmXmM0eCALTtVV9jwAHaGb?w=198&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3';

export const FALLBACK_LOGO_URL =
  'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Department_of_Agriculture_of_the_Philippines.svg/640px-Department_of_Agriculture_of_the_Philippines.svg.png';
