const API_BASE = (import.meta as any).env.VITE_API_URL || "http://localhost:5000";

export function getAuthToken(): string | null {
  return localStorage.getItem("auth_token");
}

export function setAuthSession(token: string, user: any) {
  localStorage.setItem("auth_token", token);
  localStorage.setItem("user", JSON.stringify(user));
  localStorage.setItem("isLoggedIn", "true");
}

export function clearAuthSession() {
  localStorage.removeItem("auth_token");
  localStorage.removeItem("user");
  localStorage.removeItem("isLoggedIn");
}

export async function apiFetch(path: string, init: RequestInit = {}) {
  const token = getAuthToken();
  const headers = new Headers(init.headers || {});
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (!headers.has("Content-Type") && !(init.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers,
  });
  return response;
}

export async function apiJson<T = any>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await apiFetch(path, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) {
      clearAuthSession();
    }
    const message = (data && (data.error || data.message)) || `Request failed (${response.status})`;
    throw new Error(message);
  }
  return data as T;
}

export function backendUrl(relativePath: string): string {
  if (!relativePath) return API_BASE;
  if (relativePath.startsWith("http")) return relativePath;
  return `${API_BASE}${relativePath}`;
}

export async function fetchDocumentBlob(docId: number): Promise<Blob> {
  const response = await apiFetch(`/api/documents/${docId}/file`, {
    method: "GET",
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const message = body?.error || `Failed to fetch document (${response.status})`;
    const error: any = new Error(message);
    error.response = response;
    error.body = body;
    throw error;
  }
  return response.blob();
}

export type DocumentPreview =
  | {
      type: "html";
      filename: string;
      title?: string;
      html: string;
      messages?: any[];
    }
  | {
      type: "pdf" | "image" | "download";
      filename: string;
      title?: string;
      mime?: string;
    };

export async function fetchDocumentPreview(docId: number): Promise<DocumentPreview> {
  return apiJson<DocumentPreview>(`/api/documents/${docId}/preview`);
}

export { API_BASE };
