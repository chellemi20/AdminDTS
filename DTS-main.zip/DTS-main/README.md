
  # Interactive Agriculture Dashboard (Copy)

  This is a code bundle for Interactive Agriculture Dashboard (Copy). The original project is available at https://www.figma.com/design/0Whxb4gCGrPBOW8mtlPnwc/Interactive-Agriculture-Dashboard--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  