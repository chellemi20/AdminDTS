@echo off
setlocal EnableExtensions

REM ===========================================================================
REM  DTS - Install dependencies, then launch Backend and Frontend.
REM  Frontend (Vite/React) and Backend (Express) share one root package.json,
REM  so a single "npm install" covers both.
REM ===========================================================================

cd /d "%~dp0"

echo.
echo ============================================================
echo  Document Tracking System - Install ^& Run
echo  Project: %CD%
echo ============================================================
echo.

REM --- Verify Node.js / npm are available --------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js was not found on PATH.
  echo         Install Node.js LTS from https://nodejs.org/ and try again.
  echo.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo [ERROR] npm was not found on PATH.
  echo         Reinstall Node.js LTS so npm is registered, then try again.
  echo.
  pause
  exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
for /f "tokens=*" %%v in ('npm -v') do set NPM_VER=%%v
echo  Node.js : %NODE_VER%
echo  npm     : %NPM_VER%
echo.

REM --- Install root dependencies (frontend + backend share package.json) -------
echo [1/2] Installing dependencies (npm install)...
echo --------------------------------------------------------------
call npm install
if errorlevel 1 (
  echo.
  echo [ERROR] npm install failed. Resolve the error above and rerun.
  echo.
  pause
  exit /b 1
)
echo.
echo  Dependencies installed.
echo.

REM --- Launch Backend and Frontend in separate windows -------------------------
echo [2/2] Starting Backend and Frontend in separate windows...
echo --------------------------------------------------------------
echo  Backend  : npm run start:backend   (Express, default port 5000)
echo  Frontend : npm run dev             (Vite dev server)
echo.

start "DTS Backend"  cmd /k "pushd ""%~dp0"" && npm run start:backend"
start "DTS Frontend" cmd /k "pushd ""%~dp0"" && npm run dev"

echo  Both services were launched in their own console windows.
echo  Close those windows to stop the services.
echo.
echo  This installer window can now be closed.
echo.
endlocal
pause
